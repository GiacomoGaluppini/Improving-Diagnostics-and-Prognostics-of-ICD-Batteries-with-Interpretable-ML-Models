function [featName] = x2featName(x,VariableNames)
%function [featName] = x2featName(x,VariableNames)
% Recover feature name from SPA list of features (x1 x2 x3 ... ect)
% Inputs:
% x: string, variable name from SPA (x1 x2 x3 ... ect)
% VariableNames: cell array, list of ordered variable names
% Outputs:
% featName: string, variable name corresponding to x
%%
numstr = regexp(x,'\d+','match');
idx_VN=str2num(numstr{1});
idx=find(ismember(char(x),char(numstr{1})));
x(idx)=[];
featName=strrep(string(x),'x',VariableNames{idx_VN});
end

