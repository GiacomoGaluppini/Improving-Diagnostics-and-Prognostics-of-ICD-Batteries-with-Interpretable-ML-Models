function [y] = SPAsqrt(x)
% [y] = SPAsqrt(x)
% Mimic SPA sqrt behaviour
% Inputs:
% x: array
% Outputs:
% y: array
%%
y=sqrt(abs(x));
end

