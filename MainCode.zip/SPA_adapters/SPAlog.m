function y=SPAlog(x)
% [y] = SPAlog(x)
% Mimic SPA log behaviour
% Inputs:
% x: array
% Outputs:
% y: array
%%
idxBad=find(abs(x)<=1e-10);
y=log(abs(x));
y(idxBad)=-10;
end

