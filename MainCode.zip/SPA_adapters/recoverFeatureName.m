function [VariableNames_SPA_new] = recoverFeatureName(VariableNames_SPA,VariableNames)
% function [VariableNames_SPA_new] = recoverFeatureName(VariableNames_SPA,VariableNames)
% Translate (possibly nonlinearly transformed) feature names from SPA (e.g. x1 x2 log(x1) sqrt(x1)/log(x2) ...)
% into complete feature names based on given (ordered) variable names
% Inputs:
% VariableNames_SPA: cell array, list of (possibly nonlinearly transformed) variable names in the SPA format (e.g. x1 x2 log(x1) sqrt(x1)/log(x2) ...)
% VariableNames: cell array, list of ordered variable names in the desired
% format (just base names corresponding to x1 x2 --- xn)
% Outputs:
% VariableNames_SPA_new: cell array, translated variable names
%%
VariableNames_SPA_new={};
for i=1:length(VariableNames_SPA)
    
    str=VariableNames_SPA(i);
    str=str{1};
    
    [splitstr,delims]=strsplit(str,{'/','*','^'});
    
    for j=1:length(splitstr)
        if contains(splitstr{j},'x')
            splitstr{j}=char(x2featName(splitstr{j},VariableNames));
        end
    end
    VariableNames_SPA_new{i}=strjoin(splitstr,delims);
    
end
VariableNames_SPA_new=string(VariableNames_SPA_new');

end

