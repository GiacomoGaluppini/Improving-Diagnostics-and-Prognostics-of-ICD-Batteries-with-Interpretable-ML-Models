function [y] = SPAinv(x)
% [y] = SPAinv(x)
% Mimic SPA inv behaviour
% Inputs:
% x: array
% Outputs:
% y: array
%%
idxBad=find(abs(x)<1e-9);
y=1./x;
y(idxBad)=1e9.*sign(x(idxBad));
end

