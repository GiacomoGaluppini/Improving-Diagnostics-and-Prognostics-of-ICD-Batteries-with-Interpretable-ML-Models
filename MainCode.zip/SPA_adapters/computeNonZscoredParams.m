function [model_params_unscaled,intercept] = computeNonZscoredParams(model)
% [model_params_unscaled,intercept] = computeNonZscoredParams(model)
% Given the parameters of an ALVEN model in SPA and training data scaling info (Z scoring),
% compute parameters to be used with non-Z-scored data
%Inputs:
% model: structure, as saved by SPA in "FinalResults.mat"
%Outputs:
% model_params_unscaled: array, parameters of ALVEN model for non-Z-scored data
% intercept: scalar, intercept value to be included in the ALVEN model for non-Z-scored data
%%

idx=model.final_model.ScalingInfo.retain_index;

X_mean=model.final_model.ScalingInfo.X_mean;
y_mean=model.final_model.ScalingInfo.y_mean;

X_std=sqrt(model.final_model.ScalingInfo.X_var);
y_std=sqrt(model.final_model.ScalingInfo.y_var);

model_params_unscaled=y_std.*model.model_params./X_std(idx);
intercept=y_mean-sum((y_std.*X_mean(idx).*model.model_params)./X_std(idx));
end

