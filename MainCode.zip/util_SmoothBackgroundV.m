clear all
close all
clc

%%

load('TargetFeatures_DPClustering.mat')

smoothBckgndV=cell(size(TargetFeatures.BckgndV));
for i=1:height(TargetFeatures)
    Q=TargetFeatures.Q_BckgndV{i};
    V=TargetFeatures.BckgndV{i};

    sV=smooth(Q,V,'rlowess');
    sV(1)=V(1);

    figure(1)
    clf
    plot(Q,V)
    hold on
    plot(Q,sV)

    smoothBckgndV{i}=sV;

    pause(0.5)
end

TargetFeatures=addvars(TargetFeatures,smoothBckgndV,'NewVariableNames','smoothBckgndV','After','BckgndV');

save('TargetFeatures_DPClustering.mat','TargetFeatures')
