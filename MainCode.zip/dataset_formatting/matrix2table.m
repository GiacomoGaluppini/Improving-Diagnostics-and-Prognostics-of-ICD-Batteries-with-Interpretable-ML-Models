function [Table] = matrix2table(keys,keyname,matrix,names)
% function [Table] = matrix2table(keys,keyname,matrix,names)
%  Convert matrix into Table with given variable names 
% Inputs:
% keys: array or cell array, key values
% keyname: string, name of key variable
% matrix: 2d array, data matrix
% names: cell array, list of variable names
% Outputs:
% Table: Table object
%%
Table=table(keys,'VariableNames',{keyname});
for i=1:size(matrix,2)
    Table=[Table table(matrix(:,i),'VariableNames',names(i))];
end

end

