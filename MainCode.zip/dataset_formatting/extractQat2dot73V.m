function [Q] = extractQat2dot73V(Q_BckgndV,BckgndV)

idx=find(BckgndV<=2.73,1);
isok=BckgndV(idx-1)>=2.73;
if isok
    Q=interp1(BckgndV(idx-1:idx),Q_BckgndV(idx-1:idx),2.73);
else
    if isempty(idx)
        Q=nan;
    else
        keyboard
    end
end

end