function [TablePart1,TablePart2] = addMissingVars2CombinedDataset(TablePart1,TablePart2)
% function [TablePart1,TablePart2] = addMissingVars2CombinedDataset(TablePart1,TablePart2)
% Collapse two tables which contain parts of the same dataset
%Inputs:
% TablePart1: Table object
% TablePart2: Table object
%Outputs:
% TablePart1: Table object, updated with missing variables from TablePart2
% TablePart2: Table object, updated with missing variables from TablePart1
%%
[TablePart1,TablePart2] = addMissingVars(TablePart1,TablePart2);
[TablePart2,TablePart1] = addMissingVars(TablePart2,TablePart1);
end


function [TablePart1,TablePart2] = addMissingVars(TablePart1,TablePart2)
missingVars=setdiff(TablePart1.Properties.VariableNames,TablePart2.Properties.VariableNames);
for i=1:length(missingVars)
    datum=TablePart1.(missingVars{i}){1};
    if isnumeric(datum)
        dummycol=nan(height(TablePart2),1);
    else
        dummycol=repmat({''},height(TablePart2),1);
    end
    TablePart2=addvars(TablePart2,dummycol,'NewVariableNames',missingVars{i});
end
end
