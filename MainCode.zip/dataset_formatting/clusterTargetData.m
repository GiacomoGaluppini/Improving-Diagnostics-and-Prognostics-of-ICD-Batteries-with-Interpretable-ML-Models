function [backgroundVoltData,pulseData] = clusterTargetData(experimentTargetData,useDataPoint,doPlots)
% [backgroundVoltData,pulseData] = clusterTargetData(experimentTargetData,doPlots)
% Separate background voltage and pulse voltage using DataPoint field if available, otherwise use unsupervised
% classification
% Input:
% experimentTargetData: Table, target data
% doPlots: 0 do not plot, 1 plot, 2 plot and save plot in folder 'TargetDataClustering'
% Output:
% backgroundVoltData: Table, background voltage data
% pulseData: Table, pulse data
%%
if doPlots ==2
    mkdir('TargetDataClustering')
end

featNames=lower(experimentTargetData.Properties.VariableNames);
%% cluster

%using data point idx if available
if sum(ismember(featNames,'datapoint'))>0 && useDataPoint
    DataPoint=experimentTargetData.DataPoint;
    DPdiff=diff([DataPoint(1)-1 ; DataPoint]);
    idxKm = ones(size(DPdiff));
    idxKm(DPdiff~=1)=2;
    
    bV=(experimentTargetData(idxKm==1,idxV));%background
    pV=(experimentTargetData(idxKm==2,idxV));%pulse
else %% cluster using voltage, current and impedance
    
    idxV=find(contains(featNames,'voltage'));
    idxC=find(contains(featNames,'current'));
    idxI=find(contains(featNames,'impedance'));
    idxQ=find(contains(featNames,'qd_mah'));
    
    selectedFeatIdxs=[idxV idxC idxI];
    
    % dbscan
    idxKm = dbscan(experimentTargetData{:,selectedFeatIdxs},5,round(0.5*height(experimentTargetData)));
    idxKm(idxKm==-1)=2;
    
    bV=(experimentTargetData(idxKm==1,idxV));%background
    pV=(experimentTargetData(idxKm==2,idxV));%pulse
    
    %based on average values verify if clusters are swapped, correct if needed
    if mean(bV.Voltage_V)<mean(pV.Voltage_V)
        backgroundVoltData=experimentTargetData(idxKm==2,:);
        pulseData=experimentTargetData(idxKm==1,:);
    else
        backgroundVoltData=experimentTargetData(idxKm==1,:);
        pulseData=experimentTargetData(idxKm==2,:);
    end
    
end
%% create clusters and plot





if doPlots
    scatter(backgroundVoltData.Qd_mAh,backgroundVoltData.Voltage_V,'b')
    hold on
    grid on
    scatter(pulseData.Qd_mAh,pulseData.Voltage_V,'r')
    xlabel('Q [mAh]')
    ylabel('V [V]')
    legend('Background','Pulse')
    
    if doPlots ==2
        exportgraphics(gcf,['TargetDataClustering/',experimentTargetData.SerialNumber{1},'.jpg'])
    end
end

end

