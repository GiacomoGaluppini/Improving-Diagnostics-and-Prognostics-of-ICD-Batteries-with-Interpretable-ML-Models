function [Table] = mergeVariables(Table,VarCouples,keepVar)
% function [Table] = mergeVariables(Table,VarCouples,keepVar)
% Merge two variables having different names but same meaning into a single variable
% Inputs:
% Table: Table object
% VarCouples: cell array, names of variables to be merged
% keepVar: array (2 elements) logic or 0/1. Set to 1 to keep that variable in the table,
% 0 otherwise.
% Outputs:
% Table: Table object, updated
%%
VarCouples=lower(VarCouples);
varNames=lower(Table.Properties.VariableNames);
for i=1:size(VarCouples,1)
    idx1=find(strcmp(varNames,VarCouples{i,1}));
    idx2=find(strcmp(varNames,VarCouples{i,2}));
    
    missIdxs1=find(ismissing(Table{:,idx1}));
    missIdxs2=find(ismissing(Table{:,idx2}));
    
    Table{missIdxs1,idx1}=Table{missIdxs1,idx2};
    Table{missIdxs2,idx2}=Table{missIdxs2,idx1};
    
    idxs=[idx1 idx2];
    idxBad=idxs(keepVar==0);
    Table(:,idxBad)=[];

end

end

