function [Features,FeatureNames] = extractTargetFeatures(fullTargetData,doPlots)
% function [Features,FeatureNames] = extractTargetFeatures(fullTargetData,doPlots)
% extract feature of interest (Capacity at 2.73V, Minimum voltage vs
% Capacity curves, associated to pulse 1 to 4) from Target Data Table
%Inputs:
% fullTargetData: Table, target data as loaded with "main_FormatDataset.m"
% doPlots: bool, set to 1/true to plot debug images, 2 to plot and save in current folder
%Outputs:
% Features: cell array, containing extracted features
% FeatureNames: cell array, containing names of extracted features
%%
if doPlots==2
    mkdir('TargetFeatures/Q_2_73V')
    mkdir('TargetFeatures/PulseMinV_Q')
%     mkdir('TargetFeatures/V_Overrecovery')
end

FeatureNames={};
Features={};

BackgData=fullTargetData.BackgroundTargetData{1};
NumPulses=fullTargetData.NumPulses{1};
PulseData=fullTargetData.PulseTargetData{1};
%% Capacity at 2.73V
% FeatureNames={'Q_2.73V'};
FeatureNames=[FeatureNames,'Q_2.73V'];

idx=find(BackgData.Voltage_V<=2.73,1);
if ~isempty(idx)

    Q=interp1(BackgData.Voltage_V(idx-1:idx),BackgData.Qd_mAh(idx-1:idx),2.73);
    
    if diff(BackgData.Qd_mAh(idx-1:idx))
    V=interp1(BackgData.Qd_mAh(idx-1:idx),BackgData.Voltage_V(idx-1:idx),Q);
    else
        V=2.73;
    end

    
    if doPlots
        clf
        scatter(BackgData.Qd_mAh,BackgData.Voltage_V)
        hold on
        grid on
        plot(Q,V,'xr','MarkerSize',10,'LineWidth',2)
        plot([0 1300],[2.73 2.73],'--r','MarkerSize',10,'LineWidth',2)
        xlabel('Q [mAh]')
        ylabel('V [V]')
        drawnow
        
        if doPlots==2
            exportgraphics(gcf,['TargetFeatures/Q_2_73V/',fullTargetData.SerialNumber{1},'.jpg'])
        end
    end
else
    if doPlots
        clf
        scatter(BackgData.Qd_mAh,BackgData.Voltage_V,'r')
        hold on
        grid on
        plot([0 1300],[2.73 2.73],'--r','MarkerSize',10,'LineWidth',2)
        xlabel('Q [mAh]')
        ylabel('V [V]')
        drawnow
        
        if doPlots==2
            exportgraphics(gcf,['TargetFeatures/Q_2_73V/',fullTargetData.SerialNumber{1},'.jpg'])
        end
    end
    Q=nan;
end
% Features={Q};
Features=[Features, Q];
%% Pulse Min Voltage and associated Capacity
FeatureNames=[FeatureNames,'PulseMinV_1','PulseMinV_2','PulseMinV_3','PulseMinV_4',...
    'Q_PulseMinV_1','Q_PulseMinV_2','Q_PulseMinV_3','Q_PulseMinV_4'];

PulseMinV=cell(1,4);
Q_PulseMinV=cell(1,4);
for i=1:NumPulses
    idx=i:NumPulses:height(PulseData);
    if ~isempty(idx)
    PulseMinV{i}=PulseData.Voltage_V(idx);
    Q_PulseMinV{i}=PulseData.Qd_mAh(idx);
    else
        PulseMinV{i}=nan;
        Q_PulseMinV{i}=nan;
    end
end

for i=NumPulses+1:4
    PulseMinV{i}=nan;
    Q_PulseMinV{i}=nan;
end

if doPlots
    clf
    for i=1:NumPulses
        scatter(Q_PulseMinV{i},PulseMinV{i})
        hold on
        grid on
        xlabel('Q [mAh]')
        ylabel('V [V]')
    end
    drawnow
    legend
    if doPlots==2
        exportgraphics(gcf,['TargetFeatures/PulseMinV_Q/',fullTargetData.SerialNumber{1},'.jpg'])
    end
end

Features=[Features, PulseMinV, Q_PulseMinV];

%% Background Voltage (WITH CURRENT AND TEMPERATURE)

FeatureNames=[FeatureNames,'BckgndV','smoothBckgndV','Q_BckgndV','T_BckgndV'];

BckgndV=BackgData.Voltage_V;
BckgndV_Q=BackgData.Qd_mAh;
T_BckgndV=BackgData.Temperature;

smoothBckgndV=smooth(BckgndV_Q,BckgndV,'rlowess');
smoothBckgndV(1)=BckgndV(1);

Features=[Features, BckgndV, smoothBckgndV, BckgndV_Q, T_BckgndV];

end