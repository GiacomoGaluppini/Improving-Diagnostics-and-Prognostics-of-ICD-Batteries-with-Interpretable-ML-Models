function [Table,nameD] = computeDifferentialFeatures(Table)
% [Table,nameD] = computeDifferentialFeatures(Table)
% Copute new features by taking the difference of existing feature couples
% whose names follow this convention: 
% post-pre=diff
% end-start=duration
% final-init=diff
%Inputs:
% Table: table object, with features 
%Outputs:
% Table: table object, updated with differential features; 
% new features are included at the end of Table.
% nameD: cell array, names of new features
%%
featNames=Table.Properties.VariableNames;
featNamesLower=lower(featNames);

strcouples={'post','pre','diff';...
            'end','start','duration';...
            'final','init','diff'};


diffFeature={};
nameD={};
for i=1:size(strcouples,1)
    
    fine=strcouples{i,1};
    inizio=strcouples{i,2};
    differenza=strcouples{i,3};
    
    for j=1:length(featNamesLower)
        hasFinal=contains(lower(featNamesLower{j}),fine);
        
        if hasFinal
            
            idxF=j;
            nameF=featNamesLower{idxF};
            nameI=strrep(nameF,fine,inizio);
            idxI=find(ismember(featNamesLower,nameI));
            
            
            
            if ~isempty(idxI)
                if isnumeric(Table{:,idxF}) && isnumeric(Table{:,idxI})
                    diffFeature{end+1}=Table{:,idxF}-Table{:,idxI};
                    nameD{end+1}=strrep(nameF,fine,differenza);
                end
            end
        end
    end
end

for i=1:length(diffFeature)
Table=addvars(Table,diffFeature{i},'NewVariableNames',nameD{i});
end

end

