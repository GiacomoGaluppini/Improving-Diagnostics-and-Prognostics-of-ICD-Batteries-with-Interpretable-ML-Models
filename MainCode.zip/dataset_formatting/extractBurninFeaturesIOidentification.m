function [Features,FeatureNames,FitVals,Vars] = extractBurninFeaturesIOidentification(BurninData,doPlots)
% function [Features,FeatureNames,FitVals,Vars] = extractBurninFeatures(BurninData,doPlots)
% DEPRECATED: extract features from burning data table (modelling as dynamic systems, features are parameters of LTI models (identification toolbox process models))
%Inputs:
% BurninData: Table, burnin data as loaded with "main_FormatDataset.m"
% doPlots: bool, set to 1/true to plot debug images in current folder
%Outputs:
% Features: 2d array, containing extracted features
% FeatureNames: cell array, containing names of extracted features
% FitVals: 2d array, goodness of fit values aasociated to each features
% Vars: 2d array, variance values aasociated to each features
%%

%% Step 1

try
    StepData=BurninData(find(BurninData.StepNumber==1),:);
    Features=[mean(StepData.Voltage_V)];
    FitVals=[Inf];
    Vars=[0];
catch
    Features=[nan];
    FitVals=[nan];
    Vars=[nan];
end
FeatureNames={'Step1_meanV'};

%% Step 2
try
StepData=BurninData(find(BurninData.StepNumber==2),:);

[TestTime,idx]=unique(StepData.TestTime);
dT=min(diff(TestTime));
t=min(TestTime):dT:max(TestTime);
Y=interp1(TestTime,StepData.Voltage_V(idx),t)';
Y=Y-Y(1);
U=interp1(TestTime,StepData.Current_A(idx),t)';
stepAmp=min(U);
dat=iddata([zeros(10,1);Y],[zeros(10,1);U],dT);
opt = procestOptions('InitialCondition','zero');
sys = procest(dat,'P2Z',opt);
FitVals=[FitVals sys.Report.Fit.FitPercent];
Vars=[Vars diag(sys.Report.Parameters.FreeParCovariance)'];

if doPlots
figure(200)
subplot(2,1,1)
plot(dat)
subplot(2,1,2)
compare(dat,sys);
end

Features=[Features getpvec(sys)'];

catch
    Features=[Features nan(1,4)];
    FitVals=[FitVals nan];
    Vars=[Vars nan(1,4)];
end


FeatureNames=[FeatureNames 'Step2_Kp','Step2_Tp1','Step2_Tp2','Step2_Tz'];


%% Step 3

try
StepData=BurninData(find(BurninData.StepNumber==3),:);

[TestTime,idx]=unique(StepData.TestTime);
dT=mean(diff(TestTime));
t=min(TestTime):dT:max(TestTime);
Y=interp1(TestTime,StepData.Voltage_V(idx),t)';
Y=Y-Y(1);
U=[-stepAmp*ones(size(Y))];
dat=iddata([zeros(10,1);Y],[zeros(10,1);U],dT);
opt = procestOptions('InitialCondition','zero');
sys = procest(dat,'P2Z',opt);
FitVals=[FitVals sys.Report.Fit.FitPercent];
Vars=[Vars diag(sys.Report.Parameters.FreeParCovariance)'];

if doPlots
figure(300)
subplot(2,1,1)
plot(dat)
subplot(2,1,2)
compare(dat,sys);
end

Features=[Features getpvec(sys)'];

catch
    Features=[Features nan(1,4)];
    FitVals=[FitVals nan];
    Vars=[Vars nan(1,4)];
end
FeatureNames=[FeatureNames 'Step3_Kp','Step3_Tp1','Step3_Tp2','Step3_Tz'];

%% Step 4

StepData=BurninData(find(BurninData.StepNumber==4),:);
dI=diff(StepData.Current_A);
[~,locs] = findpeaks(abs(dI),'SortStr','descend','NPeaks',8);
locs=[sort(locs); length(StepData.Current_A)];

for i=1:8
    SD=StepData(locs(i):locs(i+1)-2,:);
    
    [TestTime,idx]=unique(SD.TestTime);
    dT=mean(diff(TestTime));
    t=min(TestTime):dT:max(TestTime);
    Y=interp1(TestTime,SD.Voltage_V(idx),t)';
    Y=Y-Y(1);
    U=interp1(TestTime,SD.Current_A(idx),t)';
    U=U-U(1);
    dat=iddata([zeros(10,1);Y],[zeros(10,1);U],dT);
    opt = procestOptions('InitialCondition','zero');
    sys = procest(dat,'P2Z',opt);
    FitVals=[FitVals sys.Report.Fit.FitPercent];
    Vars=[Vars diag(sys.Report.Parameters.FreeParCovariance)'];
    
    if doPlots
    figure(400+i)
    subplot(2,1,1)
    plot(dat)
    subplot(2,1,2)
    compare(dat,sys);
    end
    
    
    Features=[Features getpvec(sys)'];
    FeatureNames=[FeatureNames ['Step3_',num2str(i),'_Kp'],...
        ['Step3_',num2str(i),'_Tp1'],['Step3_',num2str(i),'_Tp2'],['Step3_',num2str(i),'_Tz']];
end

%% Step 5
try
stepAmp=-max(U);
StepData=BurninData(find(BurninData.StepNumber==5),:);

[TestTime,idx]=unique(StepData.TestTime);
dT=mean(diff(TestTime));
t=min(TestTime):dT:max(TestTime);
Y=interp1(TestTime,StepData.Voltage_V(idx),t)';
Y=Y-Y(1);
U=[-stepAmp*ones(size(Y))];
dat=iddata([zeros(10,1);Y],[zeros(10,1);U],dT);
opt = procestOptions('InitialCondition','zero');
sys = procest(dat,'P2Z',opt);
FitVals=[FitVals sys.Report.Fit.FitPercent];
Vars=[Vars diag(sys.Report.Parameters.FreeParCovariance)'];

if doPlots
figure(500)
subplot(2,1,1)
plot(dat)
subplot(2,1,2)
compare(dat,sys);
end

Features=[Features getpvec(sys)'];

catch
    Features=[Features nan(1,4)];
    FitVals=[FitVals nan];
    Vars=[Vars nan(1,4)];
end

FeatureNames=[FeatureNames 'Step5_Kp','Step5_Tp1','Step5_Tp2','Step5_Tz'];

%% Step 6
try
StepData=BurninData(find(BurninData.StepNumber==6),:);
FitVals=[FitVals Inf];
Vars=[Vars 0];

Features=[Features mean(StepData.Voltage_V)];

catch
    Features=[Features nan(1,1)];
    FitVals=[FitVals nan];
    Vars=[Vars nan(1,1)];
end

FeatureNames=[FeatureNames 'Step6_meanV'];

