clear all
close all
clc
% 

% ThisTable=readtable("D:\OneDrive - Massachusetts Institute of Technology\Materiale Batterie\Batterie_Dataset_Medtronic\Data\Data\Production Data\BlackwellProductionData_v3 (1).xlsx");
%%
% TableName='FullTargetData';
% TableName='DataTableClean';
% TableName='DataTableSpread';
% TableName='ProductionData';
% TableName='ProductionDataClean';
% TableName='ProductionData4Merge';
% TableName='TargetFeatures';

%%

% %%% use data from 64J pulse experiments only
% TargetFeatures=TargetFeatures([TargetFeatures.JoulesDelivered{:}]==64,:);
% TargetFeatures=removevars(TargetFeatures,'JoulesDelivered');
% 
% %%% use data from 4 pulse sequence experiments only
% TargetFeatures=TargetFeatures([TargetFeatures.NumPulses{:}]==4,:);
% TargetFeatures=removevars(TargetFeatures,'NumPulses');
%%
ThisTable=eval(TableName);
varnames=ThisTable.Properties.VariableNames;
%% 
clc
name='cathode'
idx=find(contains(lower(varnames),lower(name)));

checkTable=ThisTable(:,[1 idx]);

%% processing

Q_threshold=500;
Qmax=nan(height(checkTable),1);
Qtotdiff=[];
for i=1:height(checkTable)
    Qmax(i)=max(checkTable(i,:).Q_BckgndV{:});
end

idxBad=find(Qmax<Q_threshold);
idxGood=setdiff([1:height(checkTable)],idxBad);

checkTable=checkTable(idxBad,:);
Qmax=Qmax(idxBad);
checkTable=addvars(checkTable,Qmax);
checkTable=removevars(checkTable,'Q_BckgndV');
checkTable=removevars(checkTable,'BckgndV');

figure()
hold on
for i=1:length(idxGood)
    plot(TargetFeatures.Q_BckgndV{idxGood(i)},TargetFeatures.BckgndV{idxGood(i)},'x');
end


%%

if size(checkTable,2)>1
writetable(checkTable, [name,'_checkTable.xlsx']) 
end


