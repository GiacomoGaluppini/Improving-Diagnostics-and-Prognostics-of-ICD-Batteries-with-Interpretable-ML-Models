clear all
close all
clc

presenceThreshold=0.75;

Qregion=[];
Qmaxthreshold=[];

numPulses=4;
numJoules=64;
pulseNum=4;

useBurninTimeseriesData=1;
SPAfoldername=['PulseMinV',num2str(numJoules),'JP',num2str(numPulses),'_np',num2str(pulseNum),'_Prediction_v3_Pyc']

if useBurninTimeseriesData
    SPAfoldername=[SPAfoldername,'_Burnin'];
end

mkdir(SPAfoldername)
%% load production data 

load('ProductionDataV3.mat')

%%%handle timestamped features
BaselineTimeVarName='FILL_Weight_Post-Weight 1DateTime';
[ProductionDataClean,~] = setBaselineTimer4ProdData(ProductionData,BaselineTimeVarName,true);
[ProductionDataClean,diffFeatNames] = computeDifferentialFeatures(ProductionDataClean);

%%% load material properties and join with prod data
load('x0007981010x3ACathodeMix.mat')
ProductionDataClean=outerjoin(ProductionDataClean,x0007981010x3ACathodeMix,'Type','left','MergeKeys',true);

%%% remove features that won'tbe used (categorical vars for now)
idxGood=[1 2];
for i=3:size(ProductionDataClean,2)
    if strcmpi(class(ProductionDataClean{:,i}),'double')
        idxGood=[idxGood i];
    end
end

ProductionDataClean=ProductionDataClean(:,idxGood);

%% load burnin features

load('BurninFeatures_catch22.mat','BurninFeatures')
BIfeats_c22=BurninFeatures;

load('BurninFeatures_IO.mat','BurninFeatures')
BIfeats_IO=BurninFeatures;

BurninFeatures=join(BIfeats_c22,BIfeats_IO);
%% load targte features

load('TargetFeatures_DPClustering.mat')
idx=3+find(~contains(TargetFeatures.Properties.VariableNames(4:end),['PulseMinV_',num2str(pulseNum)]));
TargetFeatures(:,[idx])=[];

%%% clean incomplete records
[TargetFeaturesClean] = removeIncompleteRecords(TargetFeatures);

%%% use data from 32/64J pulse experiments only
TargetFeaturesClean=TargetFeaturesClean([TargetFeaturesClean.JoulesDelivered{:}]==numJoules,:);
TargetFeaturesClean=removevars(TargetFeaturesClean,'JoulesDelivered');

%%% use data from 1/4 pulse sequence experiments only
TargetFeaturesClean=TargetFeaturesClean([TargetFeaturesClean.NumPulses{:}]==numPulses,:);
TargetFeaturesClean=removevars(TargetFeaturesClean,'NumPulses');

%% merge and organize

sn=intersect(ProductionDataClean.SerialNumber,TargetFeaturesClean.SerialNumber);
if useBurninTimeseriesData
    sn=intersect(sn,BurninFeatures.SerialNumber);
end

ProductionData4Merge=ProductionDataClean(ismember(ProductionDataClean.SerialNumber,sn),:);
TargetFeatures4Merge=TargetFeaturesClean(ismember(TargetFeaturesClean.SerialNumber,sn),:);
if useBurninTimeseriesData
    BurninFeatures4Merge=BurninFeatures(ismember(BurninFeatures.SerialNumber,sn),:);
end

DataTableClean = join(ProductionData4Merge,TargetFeatures4Merge);
if useBurninTimeseriesData
    DataTableClean = join(DataTableClean,BurninFeatures4Merge);
end

%%% Remove unreliable data
load('ExclusionTable.mat')
SNexcluded=intersect(DataTableClean.SerialNumber,ExclusionTable.SerialNumber);
idxBad=find(ismember(DataTableClean.SerialNumber,ExclusionTable.SerialNumber));
DataTableClean(idxBad,:)=[];

%%% clean useless columns (too many missing data) and incomplete records
[DataTableClean] = removeIncompleteFeatures(DataTableClean,presenceThreshold);
[DataTableClean] = removeIncompleteRecords(DataTableClean);

%% extract max Q for each battery and remove those that have not discharged enough

if ~isempty(Qmaxthreshold)
    Qmax=nan(height(DataTableClean),1);
    for i=1:height(DataTableClean)
        Qmax(i)=max(DataTableClean{i,end}{:});
    end
    idxBad=find(Qmax<Qmaxthreshold);
    DataTableClean(idxBad,:)=[];
    
end
%% spread pulse min records

selVarNames={['PulseMinV_',num2str(pulseNum)],['Q_PulseMinV_',num2str(pulseNum)]};
[DataTableSpread] = spreadVectorVariableOverTable(DataTableClean,selVarNames);

%move target variable as last column for SPA
DataTableSpread = movevars(DataTableSpread,['PulseMinV_',num2str(pulseNum)],'After',size(DataTableSpread,2));

%% remove nonsense target values

idxBad1=find(DataTableSpread.(['PulseMinV_',num2str(pulseNum)])>2.4);
idxBad2=find(DataTableSpread.(['PulseMinV_',num2str(pulseNum)])<0.1);
idxBad=[idxBad1;idxBad2];
DataTableSpread(idxBad,:)=[];
%% remove  Outliers
% [DataTableSpread] = rmoutliers4Tables(DataTableSpread,'mean');
%% remove columns of 0 variance
varTolerance=1e-10;

vars=var(DataTableSpread{:,3:end});
idx_all_zeros = 2+find(vars<=varTolerance);
idx_good=setdiff(1:size(DataTableSpread,2),idx_all_zeros);
DataTableSpread=DataTableSpread(:,idx_good);


%% Focus on capacity interval 
if ~isempty(Qregion)
keyboard

QsplitLowMid=900;
QsplitMidHigh=1050;

figure()
scatter(DataTableSpread.(['Q_PulseMinV_',num2str(pulseNum)]),DataTableSpread.(['PulseMinV_',num2str(pulseNum)]))
grid on

switch Qregion
    case 'L'
        idxBadQ=find(DataTableSpread.(['Q_PulseMinV_',num2str(pulseNum)])>QsplitLowMid);
    case 'M'
        idxBadQ1=find(DataTableSpread.(['Q_PulseMinV_',num2str(pulseNum)])<QsplitLowMid);
         idxBadQ2=find(DataTableSpread.(['Q_PulseMinV_',num2str(pulseNum)])>QsplitMidHigh);
         idxBadQ=[idxBadQ1;idxBadQ2];
    case 'H'
        idxBadQ=find(DataTableSpread.(['Q_PulseMinV_',num2str(pulseNum)])<QsplitMidHigh);
end

DataTableSpread(idxBadQ,:)=[];

hold on
xline(QsplitLowMid,'--k')
xline(QsplitMidHigh,'--k')
% scatter(DataTableSpread.(['Q_PulseMinV_',num2str(pulseNum)]),DataTableSpread.(['PulseMinV_',num2str(pulseNum)]))
grid on
xlabel('Q [mA\h]')
ylabel('Pulse Min.Voltage [V]')

end

%% plot and verify 

figure(313)
scatter(DataTableSpread{:,end-1},DataTableSpread{:,end})
hold on
for i=1:height(DataTableClean)
    plot(DataTableClean.(['Q_PulseMinV_',num2str(pulseNum)]){i},DataTableClean.(['PulseMinV_',num2str(pulseNum)]){i},'x')
end


%% save group labels
keyboard

GroupLabels=DataTableSpread.LotNumber;
GroupIdxs=nan(size(GroupLabels));
for i=1:length(GroupLabels)
    if isnan(GroupIdxs(i))
        idx=find(ismember(GroupLabels,GroupLabels{i}));
        GroupIdxs(idx)=i*ones(size(idx));
    end
end

writematrix(GroupIdxs, [SPAfoldername,'\GroupIdxs.txt'])
% writematrix(GroupIdxs, [SPAfoldername,'\GroupIdxs.xlsx'])

[~,idxs]=unique(GroupIdxs);
GroupTable=table(GroupLabels(idxs),GroupIdxs(idxs),'VariableNames',{'LotNumber','GroupIdxs'})
writetable(GroupTable, [SPAfoldername,'\GroupTable.txt'])
% writetable(GroupTable, [SPAfoldername,'\GroupTable.xlsx'])

ngroups=length(unique(GroupLabels))
ndata=height(DataTableSpread)
DataTableSpread=removevars(DataTableSpread,'LotNumber');

%% save main SPA file

SPATable=removevars(DataTableSpread,'SerialNumber');
writetable(SPATable, [SPAfoldername,'\SPATable.txt'],'WriteVariableNames',0)
% writetable(SPATable, [SPAfoldername,'\SPATable.xlsx'],'WriteVariableNames',0)
%% save variable names
writecell(SPATable.Properties.VariableNames', [SPAfoldername,'\VariableNames.txt'])
% writecell(SPATable.Properties.VariableNames', [SPAfoldername,'\VariableNames.xlsx'])

%% save overall mat

save([SPAfoldername,'\workspace.mat'])

