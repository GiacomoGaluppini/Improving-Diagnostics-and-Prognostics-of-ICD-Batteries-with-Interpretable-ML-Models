clear all
close all
clc

%%

load('TargetFeatures_DPClustering.mat','TargetFeatures')
TF1=TargetFeatures;

load('TargetFeatures_DPClustering_merge.mat','TargetFeatures')
TF2=TargetFeatures;
TF2=removevars(TF2,{'JoulesDelivered','NumPulses',});

TargetFeatures=join(TF1,TF2,'Keys','SerialNumber');

save('TargetFeatures_DPClustering.mat','TargetFeatures')