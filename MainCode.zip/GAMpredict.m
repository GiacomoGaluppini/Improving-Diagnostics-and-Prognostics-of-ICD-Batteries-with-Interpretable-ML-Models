function [MdlTable] = GAMpredict(Mdl,DataTableSpread)
%%TODO
%%
idxX=[];
for i=1:length(Mdl.PredictorNames)
    idxX=[idxX find(ismember(DataTableSpread.Properties.VariableNames,Mdl.PredictorNames(i)))];
end
idxY=find(ismember(DataTableSpread.Properties.VariableNames,Mdl.ResponseName));
idxSN=find(ismember(DataTableSpread.Properties.VariableNames,'SerialNumber'));

y_hat=predict(Mdl,DataTableSpread{:,idxX});

MdlTable=DataTableSpread(:,[idxSN idxX idxY]);
MdlTable=addvars(MdlTable,y_hat,'NewVariableNames',[Mdl.ResponseName,'_hat']);

end