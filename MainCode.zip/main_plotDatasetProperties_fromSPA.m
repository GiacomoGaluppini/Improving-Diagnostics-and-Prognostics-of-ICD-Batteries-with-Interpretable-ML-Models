clear all
close all
clc

folder='D:\OneDrive - Massachusetts Institute of Technology\Tesi_Medtronic\Results\Qat2_73V_Prediction_v3\'
load([folder,'NonlinearityAssess.mat'])
load([folder,'CollinearityAssess.mat'])
load([folder,'CorrAssess.mat'])

doSave=1;
%% Correlations y/x

figure(1)
ax=subplot(3,1,1);
bar(lincorr)
grid on
title('Linear Correlation')
xlabel('Variable Num')
ylabel('\rho')

subplot(3,1,2)
bar(maxcorr,'r')
grid on
title('Maximal Correlation')
xlabel('Variable Num')
ylabel('\psi')

subplot(3,1,3)
bar(maxcorr-abs(lincorr),'k')
grid on
hold on
yline(0.4,'--r')
title('Correlation Difference')
xlabel('Variable Num')
ylabel('\psi-|\rho|')


if doSave
nome=[folder,'Correlations_yx'];
exportgraphics(gcf, [nome,'.tiff'] ,'ContentType','image','Resolution',400)
savefig(gcf,[nome,'.fig'])
end
%% bilinear test

figure(2)
heatmap(bilineartest)
grid on
ylabel('Variable Num')
ylabel('Variable Num')
title('p-value of Bilinear Test')

if doSave
nome=[folder,'Bilinear_test'];
exportgraphics(gcf, [nome,'.tiff'] ,'ContentType','image','Resolution',400)
savefig(gcf,[nome,'.fig'])
end
%% quadratic test

figure(3)
bar(quadtest)
grid on
title('Quadratic Test')
xlabel('Variable Num')
ylabel('p-value')

if doSave
nome=[folder,'Quadratic_test'];
exportgraphics(gcf, [nome,'.tiff'] ,'ContentType','image','Resolution',400)
savefig(gcf,[nome,'.fig'])
end
%% Multicollinearity test

figure(4)
bar(varianceinflation)
grid on
hold on
yline(5,'--r')
title('Collinearity Test')
xlabel('Variable Num')
ylabel('Variance Inflation Factor')

if doSave
nome=[folder,'Multicollinearity_test'];
exportgraphics(gcf, [nome,'.tiff'] ,'ContentType','image','Resolution',400)
savefig(gcf,[nome,'.fig'])
end
%% Correlations xx

figure(5)
heatmap(corr_x)
title('Linear Correlation')
ylabel('Variable Num')
ylabel('Variable Num')

if doSave
nome=[folder,'Correlations_xx'];
exportgraphics(gcf, [nome,'.tiff'] ,'ContentType','image','Resolution',400)
savefig(gcf,[nome,'.fig'])
end
%% plot scatter matrix 
keyboard

% close all
% nsplits=10;
% plotbigmatrix(SPATable{:,:},nsplits,if doSave);
% close all

%% other
close all

load([folder,'workspace.mat'],'SPATable')
varNames=SPATable.Properties.VariableNames(1:end-1)';

[~,sidx]=sort(maxcorr,'descend');
MaxcorrTable=table(varNames(sidx),maxcorr(sidx),'VariableNames',{'Feature','Max Nonlin Corr'})

[~,sidx]=sort(abs(lincorr),'descend');
LincorrTable=table(varNames(sidx),lincorr(sidx),'VariableNames',{'Feature','Lin Corr'})


if doSave
    nome=[folder,'CorrTable.xlsx'];
    writetable(LincorrTable,nome,'Sheet','LinCorr')
    writetable(MaxcorrTable,nome,'Sheet','MaxCorr')
end