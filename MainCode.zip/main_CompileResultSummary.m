clear all
close all
clc

resultsFname='Results/PulseMinV_Prediction_v3_pyc_midQ/Results_EN_GrSV_OSER/FinalResults.mat'
scoresFname='Results/PulseMinV_Prediction_v3_pyc_midQ/Results_EN_GrSV_OSER/FinalScores.mat'
scalingFname='Results/PulseMinV_Prediction_v3_pyc_midQ/Results_EN_GrSV_OSER/GeneralScaler.mat'
workspaceFname='Results/PulseMinV_Prediction_v3_pyc_midQ/workspace.mat'

outputDir='Results/PulseMinV_Prediction_v3_pyc_midQ/Results_EN_GrSV_OSER/';
outputFname=[outputDir,'ResultsSummary.xlsx'];

mdlname='EN';
%% load


load(resultsFname)
load(scoresFname)
load(scalingFname)
load(workspaceFname,'SPATabl*')


%% recover original feature names for selected ones
VariableNames=SPATable.Properties.VariableNames(1:end-1);
switch mdlname
    case 'ALVEN'
        selFeat=cellstr(eval(mdlname).final_list);
        [selFeatNames] = recoverFeatureName(selFeat,VariableNames);
    case 'EN'
        selFeatNames=string(VariableNames)';
end

%% scaling info
switch mdlname
    case 'ALVEN'
        ScalingInfo=ALVEN.final_model.ScalingInfo;
    case 'EN'
        EN.final_model.ScalingInfo=ScalingInfo;
        EN.final_model.ScalingInfo.retain_index=1:length(ScalingInfo.X_mean);
end
ScalingInfo.X_std=sqrt(ScalingInfo.X_var);
ScalingInfo.y_std=sqrt(ScalingInfo.y_var);


%% copmpute non z-scored coefficients 

[model_params_unscaled,intercept] = computeNonZscoredParams(eval(mdlname));

model_params=eval(mdlname).model_params;
idx_out=find(model_params==0);
selFeatNames(idx_out)=[];
model_params(idx_out)=[];

idx_out=find(model_params_unscaled==0);
model_params_unscaled(idx_out)=[];


%% plots and scores

if exist('SPATableTrain') && exist('SPATableTest')
    
    [yhTrain,yTrain] = evalALVENmodel(SPATableTrain,selFeatNames,model_params_unscaled,intercept);
    [gofScores(1)] = computeGofScores(yTrain,yhTrain,'Train')
    plotSPA_Results(yTrain,yhTrain,'Train');
    
    [yhTest,yTest] = evalALVENmodel(SPATableTest,selFeatNames,model_params_unscaled,intercept);
    [gofScores(2)] = computeGofScores(yTest,yhTest,'Test');
    plotSPA_Results(yTest,yhTest,'Test')
    
else
    [yhtot,ytot] = evalALVENmodel(SPATable,selFeatNames,model_params_unscaled,intercept);
    [gofScores] = computeGofScores(ytot,yhtot,'Total')
    plotSPA_Results(ytot,yhtot,'Total');
end

keyboard
%% save
T1=table([selFeatNames;'Intercept'],[model_params;0],[model_params_unscaled;intercept],'VariableNames',{'Features','Params Z-scored','Params'});

[ps,idxs]=sort(abs(T1.("Params Z-scored")),'descend');
T1=T1(idxs,:);

if isfield(eval(mdlname).model_hyper,'retain_index')
    hyper=rmfield(eval(mdlname).model_hyper,'retain_index');
else
    hyper=eval(mdlname).model_hyper;
end
T2=struct2table(hyper);
% T3=table(R2,rmse,ape);

T3=[struct2table(gofScores)];

writetable(T1,outputFname,'Sheet','Features and Params')
writetable(T2,outputFname,'Sheet','Hyperparams')
writetable(T3,outputFname,'Sheet','Final Scores')

figList = findall(groot,'Type','figure');
for i=1:length(figList)
    exportgraphics(figList(i), [outputDir,figList(i).Name,'.tiff'] ,'ContentType','image','Resolution',400)
    savefig(figList(i),[outputDir,figList(i).Name,'.fig'])
end