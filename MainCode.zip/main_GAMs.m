clear all
close all
clc

%% options

rankngMethod='fsrmrmr'
% rankngMethod='maxcorr'

useRobust=1;
useCustomTestSet=0;


NumPs=[1:13];
Nr=20;

% semi=Nr+1; % For paper results
semi=1:10;

%% workspace

workspacename='PulseMinV_AllData_Prediction_v3_Pyc';

% path='C:\Users\Windows\OneDrive - Massachusetts Institute of Technology\Tesi_Medtronic\Results - Collapsed Datasets';
path='D:\galuppin\OneDrive - Massachusetts Institute of Technology\Tesi_Medtronic\Results - Collapsed Datasets';
% path='D:\OneDrive - Massachusetts Institute of Technology\Tesi_Medtronic\Results - Collapsed Datasets';

fname=[path,'\',workspacename,'\workspace.mat'];

%%

if useCustomTestSet
    semi=0;
end

for ns=1:length(semi)

    clc
    seme=semi(ns);
    display(['Processing split with seed ', num2str(seme)])
    %% load data

    load(fname,'SPATable','GroupIdxs')

    if useCustomTestSet
        load(fname,'splitCustom')
    end

    Xoriginal=SPATable{:,1:end-1};
    Y=SPATable{:,end};

    %%

    rng(semi(ns)) % For reproducibility

    if useCustomTestSet
        isTrain=ismember(splitCustom,'train');
        isTest=ismember(splitCustom,'test');

        XTrain = Xoriginal(isTrain,:);
        YTrain = Y(isTrain);
        XTest = Xoriginal(isTest,:);
        YTest = Y(isTest);

        GroupIdxsTrain=GroupIdxs(isTrain,:);
    else
        groups=unique(GroupIdxs);
        ngroups=length(groups);
        cvpTrainTest = cvpartition(ngroups,'Holdout',0.15);

        GTrain = groups(training(cvpTrainTest));
        GTest = groups(test(cvpTrainTest));

        GroupIdxsTrain=GroupIdxs(ismember(GroupIdxs,GTrain),:);
        GroupIdxsTest=GroupIdxs(ismember(GroupIdxs,GTest),:);

        XTrain = Xoriginal(ismember(GroupIdxs,GTrain),:);
        YTrain = Y(ismember(GroupIdxs,GTrain));
        XTest = Xoriginal(ismember(GroupIdxs,GTest),:);
        YTest = Y(ismember(GroupIdxs,GTest));

    end



    close all
    rng('default')

    for j=1:length(NumPs)
        NumP=NumPs(j);
        VariableNames=SPATable.Properties.VariableNames;

        parfor i=1:Nr %parfor
            close all force
            display(['Processing: NumPredictors=',num2str(NumP),' Repetition=',num2str(i),'/',num2str(Nr)])
            [gofScoresTrain(i),gofScoresVal(i),~,~,~,~,Mdl,~,~,idxPredictors,scoresPredictors] = trainGAM(XTrain,YTrain,GroupIdxsTrain,NumP,rankngMethod,VariableNames,i,0);
            gofScoresTrain(i).Mdl=Mdl;
            gofScoresTrain(i).idxPredictors=idxPredictors;
            gofScoresTrain(i).scoresPredictors=scoresPredictors;
        end

        gofTrain{j}=gofScoresTrain;
        gofVal{j}=gofScoresVal;

        mseAvgTrain(j)=mean([gofScoresTrain.mse]);
        mseAvgVal(j)=mean([gofScoresVal.mse]);

        mseStdTrain(j)=std([gofScoresTrain.mse]);
        mseStdVal(j)=std([gofScoresVal.mse]);

        clear gofScoresTrain gofScoresVal

    end

    if useRobust==0

        bestMseAvg=min(mseAvgVal);
        idx=find(mseAvgVal==bestMseAvg);
        bestNumP=NumPs(idx)

    else

        bestMseAvg=min(mseAvgVal);
        idx=find(mseAvgVal==bestMseAvg);
        stddev=mseStdVal(idx);
        MseBar=bestMseAvg+stddev;

        mseAvgValTmp=mseAvgVal;
        mseAvgValTmp(mseAvgValTmp>MseBar)=0;
        idx=find(mseAvgValTmp>0,1);
        bestNumP=NumPs(idx);

    end

    best_gofTrain=gofTrain{idx};
    best_gofVal=gofVal{idx};

    bestMse=min([best_gofVal.mse]);
    bestSeed=find([best_gofVal.mse]==bestMse);

    bestMdl=best_gofTrain(bestSeed).Mdl;
    bestPredictorsSubset=best_gofTrain(bestSeed).idxPredictors;
    bestPredictorsSscores=best_gofTrain(bestSeed).scoresPredictors;

    close all force

    %% final training without internal crossval

    idx_final=bestPredictorsSubset;
    scores_final=bestPredictorsSscores;
    XTrain=XTrain(:,idx_final);
    XTest=XTest(:,idx_final);

    ResponseName=SPATable.Properties.VariableNames{end};
    PredictorNames=SPATable.Properties.VariableNames(:,idx_final);

    fitStdDev=1;

    mdlParams=bestMdl.ModelParameters;
    if ~isempty(bestMdl.Interactions)
        Interactions=zeros(size(bestMdl.Interactions,1),bestNumP);
        for i=1:size(bestMdl.Interactions,1)
            Interactions(i,bestMdl.Interactions(i,:))=[1 1];
        end
        Interactions=logical(Interactions);
    else
        Interactions=0;
    end
    Mdl = fitrgam(XTrain,YTrain,'PredictorNames',PredictorNames,'ResponseName',ResponseName,'Interactions',Interactions,...
        'Verbose',1,'MaxPValue',mdlParams.MaxPValue,'numPrint',mdlParams.NumPrint,...
        'InitialLearnRateForInteractions',mdlParams.InitialLearnRateForInteractions,'InitialLearnRateForPredictors',mdlParams.InitialLearnRateForPredictors,...
        'NumTreesPerInteraction',mdlParams.NumTreesPerInteraction,'NumTreesPerPredictor',mdlParams.NumTreesPerPredictor,...
        'MaxNumSplitsPerInteraction',mdlParams.MaxNumSplitsPerInteraction,'MaxNumSplitsPerPredictor',mdlParams.MaxNumSplitsPerPredictor,...
        'FitStandardDeviation',fitStdDev);


    % investigate performance

    yHatTrain=predict(Mdl,XTrain);
    yHatTest=predict(Mdl,XTest);

    [gofScoresTrainFinal] = computeGofScores(YTrain,yHatTrain,'Train');
    [gofScoresTestFinal] = computeGofScores(YTest,yHatTest,'Test');

    [~,~,yIntTrain]=predict(Mdl,XTrain,'Alpha',0.05);
    [~,~,yIntTest]=predict(Mdl,XTest,'Alpha',0.05);

    %% save numerical  results

    currDate = strrep(datestr(datetime), ':', '_');
    outdirname=[path,'/',workspacename,'/resultsGAM_',currDate];
    if useRobust
        outdirname=[outdirname,' OSER_new'];
    else
        outdirname=[outdirname,' minMSE'];
    end
    if useCustomTestSet
        outdirname=[outdirname,' CustomTestSet'];
    else
        outdirname=[outdirname,' Seed',num2str(seme)];
    end
    mkdir(outdirname);

    try
        save([outdirname,'/resultsGAM.mat'])
    catch
        save([outdirname,'/resultsGAM.mat'],'-v7.3')
    end


    T1=table([PredictorNames' ;'Intercept'],'VariableNames',{'Features'});

    interIdxs=Mdl.Interactions;
    if ~isempty(interIdxs)
        T2=table([PredictorNames(interIdxs(:,1))'],[ PredictorNames(interIdxs(:,2))'],'VariableNames',{'Feature 1','Feature 2'});
    else
        T2=table();
    end

    gofScoresFinal=[gofScoresTrainFinal;gofScoresTestFinal];
    T3=[struct2table(gofScoresFinal)];

    T4=table(NumPs',mseAvgTrain',mseAvgVal',mseStdTrain',mseStdVal','VariableNames',{'Num Predictors','Avg_MSE_Train','Avg_MSE_Validation','Std_MSE_Train','Std_MSE_Validation'});

    writetable(T1,[outdirname,'/ResultsSummary.xlsx'],'Sheet','Features')
    writetable(T2,[outdirname,'/ResultsSummary.xlsx'],'Sheet','Feature Interactions')
    writetable(T3,[outdirname,'/ResultsSummary.xlsx'],'Sheet','Final Scores')
    writetable(T4,[outdirname,'/ResultsSummary.xlsx'],'Sheet','CV details')
    %% plot and save results

    close all force

    plotSPA_Results(YTrain,yHatTrain,'Train',yIntTrain);
    plotSPA_Results(YTest,yHatTest,'Test',yIntTest);


    for i=1:length(Mdl.PredictorNames)
        figure()
        set(gcf,'Name',['PD_Plot_',Mdl.PredictorNames{i}]);
        grid on
        plotPartialDependence(Mdl,Mdl.PredictorNames(i),'IncludeIntercept',true);
    end

    % for i=1:length(Mdl.PredictorNames)
    %     figure()
    %     set(gcf,'Name',['ICE_Plot_',Mdl.PredictorNames{i}]);
    %     grid on
    %     plotPartialDependence(Mdl,Mdl.PredictorNames(i),'Conditional','absolute','IncludeIntercept',false);
    % end

    figure()
    bar(scores_final(idx_final(1:bestNumP)))
    xlabel("Predictor name")
    ylabel("Predictor importance score")
    xticks(1:bestNumP);
    xticklabels(strrep(VariableNames(idx_final(1:bestNumP)),"_","\_"))
    xtickangle(45)
    set(gcf,'Name','PredictorsRanking');
    grid on

    idx_Q=find(contains(PredictorNames,['Q_',ResponseName]));
    if ~isempty(idx_Q)
        figure()
        scatter(XTest(:,idx_Q),YTest)
        hold on
        scatter(XTest(:,idx_Q),yHatTest)
        grid on
        xlabel('Q [mAh]')
        ylabel(VariableNames(end))
        legend('Data','Model Prediction')
        set(gcf,'Name','FitPlot_vs_Q_Test');
    end

    figure()
    Ylims=[];
    for i=1:NumP
        subplot(1,NumP,i)
        Violin({[gofTrain{i}.mse]',[gofVal{i}.mse]'},bestNumP,...
            'ShowMean', false,'ShowMedian', false, 'ShowBox', false, 'DataStyle', 'scatter')

        ax=gca;
        if i==1
            ylabel({'MSE';'Right=Train, Left=Validation'})
        else
            ax.YTickLabel={};
        end

        ax.XTick=bestNumP;
        ax.XTickLabel={num2str(NumPs(i))};
        Ylims=[Ylims;ax.YLim];
    end
    for i=1:NumP
        ax=subplot(1,NumP,i);
        ax.YLim=[min(min(Ylims))   max(max(Ylims))];
    end
    set(gcf,'Name','ViolinPlot');

    figure()
    errorbar(NumPs,mseAvgTrain,mseStdTrain,'-or','LineWidth',2,'MarkerSize',10)
    hold on
    grid on
    errorbar(NumPs,mseAvgVal,mseStdVal,'-xb','LineWidth',2,'MarkerSize',10)
    if useRobust
        yline(MseBar,'--k','LineWidth',2)
    end
    xline(bestNumP,'--k','LineWidth',2)
    ylabel('Average MSE')
    xlabel('Num Predictors')
    legend('Training','Validation')
    set(gcf,'Name','Model_Choice');

    figList = findall(groot,'Type','figure');
    for i=1:length(figList)
        nome=strrep(figList(i).Name,':','-');
        exportgraphics(figList(i), [outdirname,'/',nome,'.tiff'] ,'ContentType','image','Resolution',400)
        savefig(figList(i),[outdirname,'/',nome,'.fig'])
    end


end
