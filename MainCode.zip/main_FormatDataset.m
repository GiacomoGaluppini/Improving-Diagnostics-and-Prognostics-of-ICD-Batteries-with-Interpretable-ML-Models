clear all
close all
clc


Paths.mainPath='D:\OneDrive - Massachusetts Institute of Technology\Materiale Batterie\Batterie_Dataset_Medtronic';
addpath(genpath(Paths.mainPath))

Paths.dataPath=[Paths.mainPath,'\Data\Data'];

opts.doLotTable=0;
opts.doSerialNumberTable=1;
opts.doSummaryTargetData=0;
opts.doFullTargetData=0;
opts.doResistiveLoadValues=0;
opts.doBurninData=0;
opts.doPulseData=0;
opts.doProductionData=0;
opts.doMaterialPropData=0;
opts.doSerialNumbersExclusions=0;
opts.doMPETresiduals=0;

opts.createTargetSubset=1;

opts.doPlots=1;
%% Lot table
if opts.doLotTable
    LotData=readtable([Paths.dataPath,'/Blackwell lifetest Serial numbers'],'sheet','Sheet1');
    save('LotData.mat','LotData', '-v7.3')
    
    clearvars -except Paths opts

end
%% Summary Target Data (BW Rels)
doPlots=1;
useDataPoint=true;

if opts.doSummaryTargetData
    Paths.summaryTargetDataPath=[Paths.dataPath,'/SummaryTargetData'];
    dataFolder=dir(Paths.summaryTargetDataPath);

    idx_xls=find(contains({dataFolder.name},'.xlsm'));

    tmp_sn={};
    tmp={};
    tmp_b={};
    tmp_p={};
    tmp_PulseJoule={};
    tmp_NumPulses={};
    for i=1:length(idx_xls)

        idx=idx_xls(i);
        summaryTargetData=readtable([Paths.summaryTargetDataPath,'/',dataFolder(idx).name],'Sheet','PulseData');
        sn=unique(summaryTargetData.SERN);
        empty_sn=find(cellfun(@isempty,sn));
        sn(empty_sn)=[];

        for j=1:length(sn)
            tmp{end+1}=summaryTargetData(strcmp(summaryTargetData.SERN,sn{j}),:);
        end

        tmp_sn=[tmp_sn sn'];

        if contains(dataFolder(idx).name,'32')
            J=32;
        else
            J=64;
        end
        Joules=J*ones(1,length(sn));
        tmp_PulseJoule=[tmp_PulseJoule mat2cell(Joules,1,ones(1,length(sn)))];

        if contains(dataFolder(idx).name,'Q1P')
            Np=1;
        end
        if contains(dataFolder(idx).name,'Q4P')
            Np=4;
        end
        Npulses=Np*ones(1,length(sn));
        tmp_NumPulses=[tmp_NumPulses mat2cell(Npulses,1,ones(1,length(sn)))];
    end

    summaryTargetData=table(tmp_sn',tmp_PulseJoule',tmp_NumPulses',tmp','VariableNames',{'SERN','JoulesDelivered','NumPulses','PulseTargetData'});


save('summaryTargetData.mat','summaryTargetData', '-v7.3')

clearvars -except Paths opts
end
%% Full Target Data
doPlots=2;
useDataPoint=false;

if opts.doFullTargetData
    Paths.targetDataPath=[Paths.dataPath,'/TargetData'];
    dataFolder=dir(Paths.targetDataPath);
    idx_csv=find(contains({dataFolder.name},'.csv'));
    
    tmp_sn={};
    tmp={};
    tmp_b={};
    tmp_p={};
    tmp_PulseJoule={};
    tmp_NumPulses={};
    for i=1:length(idx_csv)
        
        idx=idx_csv(i);
        fullTargetData=readtable([Paths.targetDataPath,'/',dataFolder(idx).name]);
        sn=unique(fullTargetData.SerialNumber);
        
        for j=1:length(sn)
            tmp{end+1}=fullTargetData(strcmp(fullTargetData.SerialNumber,sn{j}),:);
            
            %%separate pulse and background voltage via unsupervised
            %%classfication
            if doPlots
                figure(1)
                clf
            end
            [tmp_b{end+1},tmp_p{end+1}] = clusterTargetData(tmp{end},useDataPoint,doPlots);
           
        end
        
        tmp_sn=[tmp_sn sn'];
        
        if contains(dataFolder(idx).name,'32')
            J=32;
        else
            J=64;
        end
        Joules=J*ones(1,length(sn));
        tmp_PulseJoule=[tmp_PulseJoule mat2cell(Joules,1,ones(1,length(sn)))];
        
        if contains(dataFolder(idx).name,'Q1P')
            Np=1;
        end
        if contains(dataFolder(idx).name,'Q4P')
            Np=4;
        end
        Npulses=Np*ones(1,length(sn));
        tmp_NumPulses=[tmp_NumPulses mat2cell(Npulses,1,ones(1,length(sn)))];
    end
    
    FullTargetData=table(tmp_sn',tmp_PulseJoule',tmp_NumPulses',tmp',tmp_b',tmp_p','VariableNames',{'SerialNumber','JoulesDelivered','NumPulses','TargetData','BackgroundTargetData','PulseTargetData'});
    
    save('FullTargetData.mat','FullTargetData', '-v7.3')
    
    clearvars -except Paths opts
    
end
%% Burnin Data ()


if opts.createTargetSubset
    load('FullTargetData.mat')
    goodSN=unique(FullTargetData.SerialNumber);
end

if opts.doBurninData
    
    Paths.burninPath=[Paths.dataPath,'/Burn-in files'];
    
    dataFolder=dir(Paths.burninPath);
    idx_txt=find(contains({dataFolder.name},'.txt'));
    
    tmp_sn={};
    tmp={};
    for i=1:length(idx_txt)
        
        idx=idx_txt(i);
        BurninData=readtable([Paths.burninPath,'/',dataFolder(idx).name]);
        
        if height(BurninData)>0
            sn=unique(BurninData.SerialNumber);
            
            if opts.createTargetSubset
                sn=intersect(sn,goodSN);
            end
            
            for j=1:length(sn)
                tmp{end+1}=BurninData(strcmp(BurninData.SerialNumber,sn{j}),:);
            end
            
            tmp_sn=[tmp_sn sn'];
        end
    end
    
    BurninData=table(tmp_sn',tmp','VariableNames',{'SerialNumber','BurninData'});
    
    save('BurninData.mat','BurninData', '-v7.3')
    
    clearvars -except Paths opts
    
end
%% Pulse Data ()
if opts.doPulseData
    Paths.pulsePath=[Paths.dataPath,'/Pulse Data'];
    
    dataFolder=dir(Paths.pulsePath);
    idx_csv=find(contains({dataFolder.name},'.csv'));
    
    tmp_sn={};
    tmp={};
    for i=1:length(idx_csv)
        
        idx=idx_csv(i);
        PulseData=readtable([Paths.pulsePath,'/',dataFolder(idx).name]);
        sn=unique(PulseData.SerialNumber);
        
        for j=1:length(sn)
            
            tmpPD=PulseData(strcmp(PulseData.SerialNumber,sn{j}),:);
            fnames=unique(tmpPD.File);
            
            tmpfile={};
            for k=1:length(fnames)
                tmpPDtmp=tmpPD(strcmp(tmpPD.File,fnames{k}),:);
                tmpfile{end+1}=tmpPDtmp;

            end
            
            tmp{end+1}=tmpfile;
        end
        
        tmp_sn=[tmp_sn sn'];
    end
    
    PulseData=table(tmp_sn',tmp','VariableNames',{'SerialNumber','PulseData'});
    
    save('PulseData.mat','PulseData', '-v7.3')
    
    clearvars -except Paths opts
    
end

%% Production data VER 1
% 
% if opts.doProductionData
%     Paths.productionPath=[Paths.dataPath,'/Production Data'];
%     
%     ProdLabel=readtable([Paths.productionPath,'/VariablesList'],'sheet','Variables');
%     
%     Ylabelled=ProdLabel(contains(ProdLabel{:,2},'Y'),1);
%     Ylabelled=Ylabelled{:,1};
%     Ylabelled(strcmp(Ylabelled,''))=[];
%     
%     dataFolder=dir(Paths.productionPath);
%     idx_txt=find(contains({dataFolder.name},'.txt'));
%     
%     tmp_PD={};
%     for i=1:length(idx_txt)
%         
%         ops = detectImportOptions([Paths.productionPath,'/',dataFolder(idx_txt(i)).name], 'PreserveVariableNames', true);
%         
%         timedVaridxs=find(contains(lower(ops.VariableNames),'time'));
%         for j=1:length(timedVaridxs)
%             ops = setvaropts(ops,ops.VariableNames(timedVaridxs(j)),...
%                 'Type', 'datetime','InputFormat','ddMMMyyyy H:m:s');
%         end
%         
%         tmp_PD{i}=readtable([Paths.productionPath,'/',dataFolder(idx_txt(i)).name],ops);
%        i
% 
%     end
%     
%     for i=1:length(idx_txt)
%         fid = fopen([Paths.productionPath,'/',dataFolder(idx_txt(i)).name]);
%         a = fgets(fid);
%         fclose(fid);
%         
%         varNames{i}=strsplit(a,'	');
%         idxY{i}=find(ismember(varNames{i},Ylabelled));
%         tmp_PD{i}= tmp_PD{i}(:,idxY{i});
%     end
%     
%     [tmp_PD{1},tmp_PD{2}] = addMissingVars2CombinedDataset(tmp_PD{1},tmp_PD{2});
%  
%     for i=1:length(idx_txt)
%         [tmp_PD{i}] = str2double4Tables(tmp_PD{i});
%     end
%      
%     ProductionData=[tmp_PD{1};tmp_PD{2}];
%     save('ProductionDataNew.mat','ProductionData', '-v7.3')
%     
%     clearvars -except Paths opts
%     
% end
%% Production data from xlsx VER 3

if opts.doProductionData
    Paths.productionPath=[Paths.dataPath,'/Production Data'];
    mainFname='BlackwellProductionData_v3 (1).xlsx';
    
    sheets = sheetnames([Paths.productionPath,'/',mainFname]);
    
    if sum(contains(sheets,'Variables'))
        
        ProdLabel=readtable([Paths.productionPath,'/',mainFname],'sheet','Variables');
        
        ColumnNamesIdxs=find(contains(ProdLabel.Properties.VariableNames,'ColumnNames'));
        PredictorVariablesIdxs=find(contains(ProdLabel.Properties.VariableNames,'PredictorVariable'));
        
        ColumnNames=[];
        PredictorVariable=[];
        for i=1:length(ColumnNamesIdxs)
            ColumnNames=[ColumnNames;ProdLabel{:,ColumnNamesIdxs(i)}];
            PredictorVariable=[PredictorVariable;ProdLabel{:,PredictorVariablesIdxs(i)}];
        end
        ProdLabel=[ColumnNames PredictorVariable];
        Ylabelled=ProdLabel(contains(ProdLabel(:,2),'Y'),1);
        
    else
        display('using separate VariableList')
        ProdLabel=readtable([Paths.productionPath,'/VariablesList'],'sheet','Variables');
        
        Ylabelled=ProdLabel(contains(ProdLabel{:,2},'Y'),1);
        Ylabelled=Ylabelled{:,1};
        Ylabelled(strcmp(Ylabelled,''))=[];
    end
    
    ops = detectImportOptions([Paths.productionPath,'/',mainFname], 'PreserveVariableNames', true);
    
    timedVaridxs=find(contains(lower(ops.VariableNames),'time'));
    for j=1:length(timedVaridxs)
        ops = setvaropts(ops,ops.VariableNames(timedVaridxs(j)),...
            'Type', 'datetime','InputFormat','ddMMMyyyy H:m:s');
    end
    
    ProductionData=readtable([Paths.productionPath,'/',mainFname],ops);
    
    
    varNames=ProductionData.Properties.VariableNames;
    idxY=find(ismember(varNames,Ylabelled));
    ProductionData= ProductionData(:,idxY);
    
    missVars=setdiff(Ylabelled,ProductionData.Properties.VariableNames);
    if length(missVars)>0
        display('please review missing variables')
        missVars
        keyboard
    end
    
    [ProductionData] = str2double4Tables(ProductionData);
    
    VarCouples={'CathodeMass','CMI_Blackwell Wt thick_Net Weight'};
    [ProductionData] = mergeVariables(ProductionData,VarCouples,[1 0]);
    
    save('ProductionDataV3.mat','ProductionData', '-v7.3')
    
    clearvars -except Paths opts
    
end

%% Material Properties Data

if opts.doMaterialPropData
    Paths.materialPath=[Paths.dataPath,'/Material Properties Data'];
    
    dataFolder=dir(Paths.materialPath);
    dataFolder([dataFolder.isdir])=[];
    
    for i=1:length(dataFolder)
        
        fname=[Paths.materialPath,'/',dataFolder(i).name];
        
        TT=readtable(fname,'sheet',1);
        
        sn=unique(TT.SERIALNUMBER);
        
        means=nan(size(sn));
        stddevs=nan(size(sn));
        for j=1:length(sn)
            tmp=TT(strcmp(TT.SERIALNUMBER,sn{j}),:);
            
            sn{j}=['_',sn{j}];
            
            idxMean=find(strcmpi(tmp.PARAMETER,'lot mean'));
            if ~isempty(idxMean)
                if length(idxMean)==1
                    means(j)=tmp(idxMean,:).VALUE;
                else
                    means(j)=mean(tmp(idxMean,:).VALUE,'omitnan' );
                end
            end
            
            idxStddev=find(strcmpi(tmp.PARAMETER,'lot stdev'));
            if ~isempty(idxStddev)
                if length(idxStddev)==1
                    stddevs(j)=tmp(idxStddev,:).VALUE;
                else
                    stddevs(j)=mean(tmp(idxStddev,:).VALUE,'omitnan' );
                end
            end
        end
        
        PropertyId=readtable(fname,'sheet','PropertyId');
        TabName=char(genvarname(PropertyId{:,:}));
        
        NewVarNames={char(PropertyId{:,:}),[char(PropertyId{:,:}),' Lot Mean'],[char(PropertyId{:,:}),' Lot Stdev']};
        eval([TabName,'=table(sn,means,stddevs,''VariableNames'',NewVarNames);']);
        
        save([TabName,'.mat'],TabName, '-v7.3')
        
        clearvars -except Paths opts
    end
    
    
    
end
%% SerialNumber to SERN conversion Table old version
% if opts.doSerialNumberTable
%     Paths.pulsePath=[Paths.dataPath,'/Pulse Data'];
%     
%     dataFolder=dir(Paths.pulsePath);
%     idx_csv=find(contains({dataFolder.name},'.csv'));
%     
%     
%     for i=1:length(idx_csv)
%         idx=idx_csv(i);
%         rdtblopts = detectImportOptions([Paths.pulsePath,'/',dataFolder(idx).name],'Range','A:E');
%         rdtblopts = setvartype(rdtblopts, 'string');
%         tmp=readtable([Paths.pulsePath,'/',dataFolder(idx).name],rdtblopts);
%         tmp(:,2:4)=[];
%         if i==1
%             SernTable=tmp;
%         else
%             SernTable=[SernTable; tmp];
%         end
%         
%     end
%     
%     [SerialNumber, idx]=unique(SernTable.SerialNumber);
%     SERN=SernTable{idx,2};
%     SernTable=table(cellstr(SerialNumber),cellstr(SERN),'VariableNames',{'SerialNumber','SERN'});
%     
%     save('SernTable.mat','SernTable', '-v7.3')
%     
%     clearvars -except Paths opts
%     
%     
% end

%% CROSS CHECK TABLE (SerialNumber to SERN conversion Table NEW version)
if opts.doSerialNumberTable
    SernTable =readtable([Paths.dataPath,'/BW-LifeTestCrossCheckv2'],'sheet',1);
    save('SernTable.mat','SernTable', '-v7.3')
    
    clearvars -except Paths opts
    
    
end

%% doSerialNumbersExclusions
if opts.doSerialNumbersExclusions
    
    Paths.exlusionPath=[Paths.dataPath,'/ReliabilityIssues'];
    
    dataFolder=dir(Paths.exlusionPath);
    idx_txt=find(contains({dataFolder.name},'.txt'));
    
    for i=1:length(idx_txt)
        tmp=readtable(dataFolder(idx_txt(i)).name);
        tmpreason=repmat(cellstr(dataFolder(idx_txt(i)).name),height(tmp),1);
        tmp=addvars(tmp,tmpreason,'NewVariableNames',{'Reason'});
        if i>1
        ExclusionTable=[ExclusionTable; tmp];
        else
            ExclusionTable=tmp;
        end
    end
    
    save('ExclusionTable.mat','ExclusionTable', '-v7.3')
    
    clearvars -except Paths opts
end

%% MPET residuals
if opts.doMPETresiduals
    Paths.MPETresidualsPath=[Paths.dataPath,'/MPET residuals'];
    
    dataFolder=dir(Paths.MPETresidualsPath);
    idx_csv=find(contains({dataFolder.name},'.csv'));
    
    sn=[];
    for i=1:length(idx_csv)
        tmpfname=dataFolder(idx_csv(i)).name;
        MPETresiduals=readtable(tmpfname);
        sn=[sn;unique(MPETresiduals.serial_number)];
    end

    sn=unique(sn);

    tmp=[];
    varnames=[];
    for i=1:length(idx_csv)
        fname{i}=dataFolder(idx_csv(i)).name;
        MPETresiduals=readtable(fname{i});
        MPETresiduals = renamevars(MPETresiduals,'serial_number','SerialNumber');
        MPETresiduals = removevars(MPETresiduals,'Var1');
        
        fname{i}=fname{i}(1:end-4);
        varnames=[varnames {['exp_DOD_',fname{i}]},fname{i}];
        tmp_in={};
        for j=1:length(sn)
             tbl=MPETresiduals(strcmp(MPETresiduals.SerialNumber,sn{j}),:);
             goodvars=[find(strcmp(tbl.Properties.VariableNames,'exp_DOD')),...
                 find(strcmp(tbl.Properties.VariableNames,fname{i}))];
             tmp_in=[tmp_in; mat2cell(tbl{:,goodvars},height(tbl),[1 1])];
        end
        tmp=[tmp tmp_in];
        
    end

    MPETresiduals=table(sn,'VariableNames',{'SerialNumber'});
    for i=1:size(tmp,2)
        MPETresiduals=addvars(MPETresiduals,tmp(:,i), 'NewVariableNames',varnames{i});
    end

    save('MPETresiduals.mat','MPETresiduals', '-v7.3')

    clearvars -except Paths opts

end
%% Resistive Load Values
if opts.doResistiveLoadValues
    Paths.LifetestInfoPath=[Paths.dataPath,'/Lifetest Exp Info'];
    [status,sheets] =xlsfinfo([Paths.LifetestInfoPath,'/TestProperties BW Lifetest Resistive Load Values 20230517']);
    
    
    for i=1:length(sheets)
         tmp=readtable([Paths.LifetestInfoPath,'/TestProperties BW Lifetest Resistive Load Values 20230517'],'sheet',sheets{i});
         if i==1
            ResistiveLoadValues=tmp;
        else
            ResistiveLoadValues=[ResistiveLoadValues; tmp];
        end
    end
    [sn,idx_ok]=unique(ResistiveLoadValues.SerialNumber);
    ResistiveLoadValues=ResistiveLoadValues(idx_ok,:);
    save('ResistiveLoadValues.mat','ResistiveLoadValues', '-v7.3')

    clearvars -except Paths opts

end
