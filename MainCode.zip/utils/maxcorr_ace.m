function [psi,phi] = maxcorr_ace(x,y,wl,doPlots)
% [psi,phi] = maxcorr_ace(x,y,wl,doPlots)
% Compute maximal correlation via ace algorithm (see@ ace)
%Inputs:
% x: matrix, predictors (predictor=column)
% y: array, target data
% wl: scalar, width of smoothing kernel
% doPlots: bool, set to 1/true to plot debug images, 2 to plot and save in current folder
%Outputs:
% psi: array, pairwise maximal correlation between y and each predicotr in
% phi: matrix, transformed x-values in the same order as x.
%%
x_ace=[y,x]';

ll=size(x_ace,2); % number of data points
dim=size(x_ace,1)-1;  % number of terms on right hand side
% wl=5;   % width of smoothing kernel
oi=1000; % maximum number of outer loop iterations
ii=100;  % maximum number of inner loop iterations
ocrit=10*eps; % numerical zeroes for convergence test
icrit=1e-10;
shol=0; % 1-> show outer loop convergence, 0-> do not
shil=0; % same for inner loop

%%

[psi,phi]=ace(x_ace,ll,dim,wl,oi,ii,ocrit,icrit,shol,shil);

%%

if doPlots
    

    for d=1:dim+1;
        figure()
        plot(x_ace(d,:),phi(d,:),'.');
%         hold on;
%         plot(x_ace(d,:),exp(phi(d,:)),'g.');
%         hold off;
        axis tight;
    end;
    figure();
    if dim==1; sum0=phi(2,:); else sum0=sum(phi(2:dim+1,:)); end;
    plot(phi(1,:),sum0,'.');
    xlabel('\Phi_0'); ylabel('\Sigma \Phi_i'); title('Regression');
    
end

end

