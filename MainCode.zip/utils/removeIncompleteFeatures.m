function [Table,idxBad] = removeIncompleteFeatures(Table,threshold,varargin)
% [Table,idxBad] = removeIncompleteFeatures(Table,threshold,varargin)
% Remove incomplete variables (i.e. containing missing values) from table,
% based on a presence threshold
% Inputs:
% Table: Table object
% threshold: scalar, in ]0;1] 
% val2remove [optional]: scalar or logical. If not specified, removes based on missing values.
% If specified, removes based on val2remove
% Outputs:
% Table: Table object, updated
% idxBad: array, indexes of removed colums
%%
if nargin==3
    val2remove=varargin{1};
end

nrecords=height(Table);
idxBad=[];
for i=1:length(Table.Properties.VariableNames)
    if nargin==3
        if isnumeric(Table{1,i}) || islogical(Table{1,i})
            presencePercent=sum(Table{:,i}==val2remove)/nrecords;
            if presencePercent>=min(1,threshold)
                idxBad=[idxBad i];
            end
        end
    else
        
        presencePercent=1-sum(ismissing(Table(:,i)))/nrecords;
        if presencePercent<=min(1,threshold)
            idxBad=[idxBad i];
        end
        
    end
    
end

Table(:,idxBad)=[];
end

