function [gofScoresTrain,gofScoresTest,YTrain,YTest,yHatTrain,yHatTest,Mdl,XTrain,XTest,idxPredictors,scoresPredictors] = trainGAM(X,Y,GroupIdxs,NumP,rankngMethod,VariableNames,rngSeed,fitStdDev)
% TODO UPDATE DOC
% [gofScoresTrain,gofScoresTest,YTrain,YTest,yHatTrain,yHatTest,Mdl,XTrain,XTest] = trainGAM(X,Y,GroupIdxs,PredictorNames,ResponseName,rngSeed,fitStdDev)
%Inputs:
% X: matrix, predictors (predictor=column)
% Y: array, target data
% GroupIdxs: array, index of group for each data point
% PredictorNames: cell array, names of predictors
% ResponseName: string, name of target variable
% rngSeed: scalar, rgn seed for reproducibility of results
% fitStdDev: set to 1 to fit an addtional model for standard deviation
%Outputs:
% gofScoresTrain: struct, goodness-of-fit scores for training data (see @computeGofScores)
% gofScoresTest: struct, goodness-of-fit scores for test data (see @computeGofScores)
% YTrain: array, target data for training 
% YTest: array, target data for test
% yHatTrain: array, model prediction for training 
% yHatTest: array, model prediction for test 
% Mdl: GAMobject, generalized additive model (see @fitrgam)
% XTrain: matrix, predictors for training 
% XTest: matrix, predictors for test 
%%
rng(rngSeed) % For reproducibility

groups=unique(GroupIdxs);
ngroups=length(groups);
cvpTrainTest = cvpartition(ngroups,'Holdout',0.3);

GTrain = groups(training(cvpTrainTest));
GTest = groups(test(cvpTrainTest));

GroupIdxsTrain=GroupIdxs(ismember(GroupIdxs,GTrain),:);
GroupIdxsTest=GroupIdxs(ismember(GroupIdxs,GTest),:);

XTrain = X(ismember(GroupIdxs,GTrain),:);
YTrain = Y(ismember(GroupIdxs,GTrain));
XTest = X(ismember(GroupIdxs,GTest),:);
YTest = Y(ismember(GroupIdxs,GTest));

% filter predictors
[idxPredictors,XTrain,scoresPredictors] = filterPredictors(XTrain,YTrain,NumP,rankngMethod,VariableNames(:,1:end-1));
XTest=XTest(:,idxPredictors);

ResponseName=VariableNames{end};
PredictorNames=VariableNames(:,idxPredictors);

rng(rngSeed)

groupsTrain=unique(GroupIdxsTrain);
ngroupsTrain=length(groupsTrain);
KF=5;
cvpTrainVal = cvpartition(ngroupsTrain,'KFold',KF);

KF_ValIdxs=nan(length(GroupIdxsTrain),1);
for k=1:KF
    GVal{k} = groupsTrain(test(cvpTrainVal,k));
    GroupIdxsVal{k}=GroupIdxsTrain(ismember(GroupIdxsTrain,GVal{k}),:);
    KF_ValIdxs(ismember(GroupIdxsTrain,GVal{k}))=k;
end
cvpTrainVal = cvpartition('CustomPartition',KF_ValIdxs);


%set 'UseParallel' to false for reproducibility if using bayesopt!!!
Mdl = fitrgam(XTrain,YTrain,'PredictorNames',PredictorNames,'ResponseName',ResponseName,...
    'Verbose',0,...
    'FitStandardDeviation',fitStdDev,...
    'OptimizeHyperparameters','auto', ...
    'HyperparameterOptimizationOptions', ...
    struct('AcquisitionFunctionName','expected-improvement-plus','UseParallel',false,...
    'MaxObjectiveEvaluations',60,'CVPartition',cvpTrainVal,'ShowPlots',false,'Verbose',0));


%% investigate performance

yHatTrain=predict(Mdl,XTrain);
yHatTest=predict(Mdl,XTest);

[gofScoresTrain] = computeGofScores(YTrain,yHatTrain,'Train');
[gofScoresTest] = computeGofScores(YTest,yHatTest,'Test');
end