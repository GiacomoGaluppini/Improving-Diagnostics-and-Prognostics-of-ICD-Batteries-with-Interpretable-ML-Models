function [gofScores] = computeGofScores(y,y_hat,DatasetLabel)
% [gofScores] = computeGofScores(y,y_hat,DatasetLabel)
% Compute goodness-of-fit metrics given data and model predictions
%Inputs:
% y: array, target data
% y_hat:: array, model prediction 
% DatasetLabel: string, information about the dataset
%Outputs:
% gofScores: struct, with fields:
% gofScores.ssr: scalar, sum of squared residuals
% gofScores.mse: scalar, mean square error
% gofScores.rmse: scalar, root mean square error
% gofScores.aape: scalar, average absolute percentage error
% gofScores.R2: scalar, coeffiient of determination

%%

gofScores.DatasetLabel=DatasetLabel;

%%
e=y-y_hat;

gofScores.ssr=sum((e).^2);

gofScores.mse=mean((e).^2);
gofScores.rmse=sqrt(gofScores.mse);

gofScores.aape=mean(abs(e./y))*100;


tss=sum((y-mean(y)).^2);
gofScores.R2=1-gofScores.ssr./tss;


end

