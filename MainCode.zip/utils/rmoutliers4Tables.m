function [Table] = rmoutliers4Tables(Table,method)
% function [Table] = rmoutliers4Tables(Table,method)
% Remove outliers from data table (variablewise)
% Inputs:
% Table: Table object
% method: string or array. If string, see @rmoutliers for outlier removal method. 
% If array, see @rmoutliers, 'percentiles' option removal method. 
% Outputs:
% Table: Table object, updated
%%

idxOut=[];
for i=1:size(Table,2)
    col=Table{:,i};
    if isnumeric(col)
        if isnumeric(method)
            [~,isOutlier] = rmoutliers(col,'percentiles',method);
        else
            [~,isOutlier] = rmoutliers(col,method);
        end
        idxOutliers=find(isOutlier==1);
        idxOut=[idxOut; idxOutliers];
    end
    
end
idxOut=unique(idxOut);
idxGood=setdiff(1:height(Table),idxOut);
Table=Table(idxGood,:);
end

