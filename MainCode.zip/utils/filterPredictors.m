function [idx,X, scores] = filterPredictors(Xoriginal,Y,NumP,algorithm,VariableNames)
%  [idx,X] = filterPredictors(Xoriginal,Y,NumP,algorithm,VariableNames)
% Rank and select the first NumP predictor variables 
%Inputs:
% Xoriginal: matrix, candidate predictors (predictor=column)
% Y: array, target data
% NumP: desired number of predictors to be selected
% algorithm: string ("maxcorr" or "fsrmrmr"), selecting the ranking method
% VariableNames: cell arra, names of predictors
%Outputs:
% idx: array, indices of selected predictors
% X: matrix, selected predictors (predictor=column)
%%
switch algorithm
    case 'maxcorr'

        for i=1:size(Xoriginal,2)
            [scores(i)] = maxcorr_ace(Xoriginal(:,i),Y,35,0);
        end

        [~,idx]=sort(scores,'descend');

        bar(scores(idx(1:NumP)))
        xlabel("Predictor rank")
        ylabel("Maximal correlation")
        xticks(1:NumP);
        xticklabels(strrep(VariableNames(idx(1:NumP)),"_","\_"))
        xtickangle(45)

    case 'fsrmrmr'

        [idx, scores] = fsrmrmr(Xoriginal,Y);

        bar(scores(idx(1:NumP)))
        xlabel("Predictor rank")
        ylabel("Predictor importance score")
        xticks(1:NumP);
        xticklabels(strrep(VariableNames(idx(1:NumP)),"_","\_"))
        xtickangle(45)
end

idx=idx(1:NumP);
X=Xoriginal(:,idx);
end