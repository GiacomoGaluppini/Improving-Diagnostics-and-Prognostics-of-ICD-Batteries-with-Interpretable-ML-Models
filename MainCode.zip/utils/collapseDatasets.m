function [TargetFeatures] = collapseDatasets(TargetFeatures,masterVarName)
%%TODO
%%
masterVar=cell(height(TargetFeatures),1);
Q_masterVar=cell(height(TargetFeatures),1);
PulseNum=cell(height(TargetFeatures),1);
for i=1:height(TargetFeatures)
    for j=1:TargetFeatures{i,'NumPulses'}{1}
        nr=length(TargetFeatures{i,[masterVarName,'_',num2str(j)]}{1});
        masterVar{i}=[masterVar{i};TargetFeatures{i,[masterVarName,'_',num2str(j)]}{1}];
        Q_masterVar{i}=[Q_masterVar{i};TargetFeatures{i,['Q_',masterVarName,'_',num2str(j)]}{1}];
        PulseNum{i}=[PulseNum{i};j*ones(nr,1)];
    end
end
idx=3+find(contains(TargetFeatures.Properties.VariableNames(4:end),masterVarName));
TargetFeatures(:,[idx])=[];
TargetFeatures=addvars(TargetFeatures,PulseNum,masterVar,Q_masterVar, 'NewVariableNames', {'PulseNum',masterVarName,['Q_',masterVarName]});

end