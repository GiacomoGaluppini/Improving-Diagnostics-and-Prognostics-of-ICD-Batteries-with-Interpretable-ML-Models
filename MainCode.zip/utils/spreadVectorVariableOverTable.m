function [TableSpread] = spreadVectorVariableOverTable(TableIn,selVarNames)
% function [TableSpread] = spreadVectorVariableOverTable(TableIn,selVarNames)
% For Tables with fields containing arrays, duplicates records and spread
% arrays to obtain scalar fields only (for desired variables)
% Inputs:
% TableIn: Table object, input data conntaining array fields to be
% spread
% selVarNames: cell array, variable names of fields conntaining arrays to be
% spread
% Outputs:
% TableSpread: Table object, updated TableIn
%%

idx=find(ismember(TableIn.Properties.VariableNames,selVarNames));
sizes=cellfun(@length,TableIn{:,idx(1)});

idxBad=setdiff(1:size(TableIn,2),idx);
TableSpread=TableIn(1,idxBad);
for i=1:length(sizes)
    
    for j=1:sizes(i)
        TableSpread=[TableSpread;TableIn(i,idxBad)];
    end
    
    if i==1
        TableSpread(1,:)=[];
    end
end

for i=1:length(idx)
    c=cell2mat(TableIn{:,idx(i)}),sum(sizes);
    [TableSpread] = addvars(TableSpread,c,'NewVariableNames',TableIn.Properties.VariableNames(idx(i)));
end
end

