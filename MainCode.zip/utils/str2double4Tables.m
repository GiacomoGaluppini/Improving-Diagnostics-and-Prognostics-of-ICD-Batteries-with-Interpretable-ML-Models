function [Table] = str2double4Tables(Table)
% function [Table] = str2double4Tables(Table)
% Convert string fields of Table into doubles (with the exception of SerialNumber and LotNumber fields)
% Inputs:
% Table: Table object
% Outputs:
% Table: Table object, updated
%%

featNames=Table.Properties.VariableNames;

for i=1:size(Table,2)
    
    if ~strcmpi(featNames{i},'SerialNumber') && ~strcmpi(featNames{i},'LotNumber')
        
        col=Table{:,i};
        idx=~ismissing(col);
        if iscell(col)
            colgood=[col{idx}];
        else
            colgood=[col(idx)];
        end
        if ischar(colgood) || isstring(colgood)
            if all(ismember(colgood, '0123456789+-.Ee')) && ~sum(ismember(colgood, '_:'))
                col2=str2double(col);
                Table=removevars(Table,featNames(i));
                Table=addvars(Table,col2,'NewVariableNames',featNames(i),...
                    'After',featNames(i-1));
            end
        end
        
    end
end
end

