function [ProductionData,DurationsTable] = setBaselineTimer4ProdData(ProductionData,BaselineTimeVarName,cast2double)
% function [ProductionData,DurationsTable] = setBaselineTimer4ProdData(ProductionData,BaselineTimeVarName,cast2double)
% Convert absolute datetime data into durations, using a desired variable
% as baseline timestamp.
% Inputs:
% ProductionData: Table object, containing production data
% BaselineTimeVarName: string, name of variable to be used as baseline
% timestamp
% cast2double: bool, if true, cast durations into doubles
% Outputs:
% ProductionData: Table, updated production data
% DurationsTable: Table, durations variables only
%%
featNames=ProductionData.Properties.VariableNames;

idxBase=find(contains(lower(featNames),lower(BaselineTimeVarName)));
t0=ProductionData{:,idxBase};
missing_t0=find(ismissing(t0));
%%
idx=[];
for i=1:length(featNames)
    if isdatetime(ProductionData{:,i})
    idx=[idx i];
    end
end

durations=[];
for i=1:length(idx)
    
    tmp=ProductionData{:,idx(i)};
    

    missing_tmp=find(ismissing(tmp));
    
    missing_all=unique([missing_t0;missing_tmp]);
    idx_ok=setdiff(1:length(tmp),missing_all);
    
    dur=duration(nan(length(tmp),3));
    dur(idx_ok)=tmp(idx_ok)-t0(idx_ok);
    
    durations=[durations dur];

end

if cast2double
    durations=minutes(durations);
end

[DurationsTable] = matrix2table(ProductionData.SerialNumber,'SerialNumber',durations,featNames(idx));
ProductionData=removevars(ProductionData,featNames(idx));
ProductionData=join(ProductionData,DurationsTable);

featNamesNew=ProductionData.Properties.VariableNames;
idx=[];
for i=1:length(featNamesNew)
    idx(i)=find(strcmp(featNames{i},featNamesNew));
end

ProductionData=ProductionData(:,idx);
ProductionData=removevars(ProductionData,BaselineTimeVarName);
end

