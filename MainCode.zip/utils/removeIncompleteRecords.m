function [Table,idxBad] = removeIncompleteRecords(Table)
% function [Table,idxBad] = removeIncompleteRecords(Table)
% Remove incomplete records (i.e. containing missing values) from table
% Inputs:
% Table: Table object
% Outputs:
% Table: Table object, updated
% idxBad: array, indexes of removed rows
%%

idxBad=find(any(ismissing(Table),2));

if isempty(idxBad)
    for i=1:size(Table,2)
        c=Table{:,i};
        for j=1:length(c)
            e=c{j};
            if sum(ismissing(e))
                idxBad=[idxBad j];
            end
        end
    end
end

idxBad=unique(idxBad);

Table=Table(setdiff(1:height(Table),idxBad),:);

end

