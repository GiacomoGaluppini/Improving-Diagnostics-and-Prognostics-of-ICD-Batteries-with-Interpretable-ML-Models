clear all
close all
clc

%% load

load('FullTargetData_DPClustering.mat')
doPlots=0;

%% extract target features

TFdata=[];
for i=1:height(FullTargetData)
%      try
        if doPlots
            figure(1)
            clf
        else
            i
        end
        [Features,Names] = extractTargetFeatures(FullTargetData(i,:),doPlots);
%     catch
%         Features=cell(1,length(Features));
%     end
    TFdata=[TFdata; Features];
    
    
    if mod(i,50)==0
        save('TargetFeaturesFull_DPClustering.mat')
        close all
    end
    
end

[TargetFeatures] = matrix2table(FullTargetData.SerialNumber,'SerialNumber',TFdata,Names);
[TargetFeatures] = addvars(TargetFeatures,FullTargetData.JoulesDelivered,...
    'After','SerialNumber','NewVariableNames',{'JoulesDelivered'});
[TargetFeatures] = addvars(TargetFeatures,FullTargetData.NumPulses,...
    'After','JoulesDelivered','NewVariableNames',{'NumPulses'});


save('TargetFeaturesFull_DPClustering.mat')

%% save useful tables

clearvars -except TargetFeatures

save('TargetFeatures_DPClustering.mat')