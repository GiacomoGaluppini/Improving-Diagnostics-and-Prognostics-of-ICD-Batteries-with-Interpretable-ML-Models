clear all
close all
clc

%%
fname='D:\OneDrive - Massachusetts Institute of Technology\Tesi_Medtronic\Results - Collapsed Datasets\SmoothedBckgndV_AllData_Prediction_v3_Pyc_Lifetest\resultsGAM_31-Oct-2023 21_01_48 OSER_TestData\Fit_Plot_2_Test.fig'
uiopen(fname,1)

ultimo=get(gca,'xlim');
xlim([ceil(ultimo/5)])
set(gcf,'Name',[fname(1:end-4),'_Zoom']);

ax=gca;
ax.Legend.Location='best';
exportgraphics(gcf, [fname(1:end-4),'_Zoom.tiff'] ,'ContentType','image','Resolution',400)

