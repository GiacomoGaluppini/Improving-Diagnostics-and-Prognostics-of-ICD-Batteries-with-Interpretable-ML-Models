function plotbigmatrix(X,nsplits,doSave)
% plotbigmatrix(X,nsplits,doSave)
% plot scetter matrix over several figures when X is high dimensional (see @plotmatrix)
% Inputs:
% X: 2d array, data matrix
% nsplits: scalar, number of splits to be used (total figures=nplits*nsplits)
% doSave: bool, set to true to save figures in a folder 'scattermatrix_plot', placed in the current folder
%%
n=size(X,2);
l=floor(n/nsplits);
r=rem(n,nsplits);

if r
    nsplits=nsplits+1;
end

if nsplits<10
    nfactor=10;
else
    nfactor=100;
end

cartella='scattermatrix_plot';
if doSave
    mkdir(cartella)
end

for i=1:nsplits
    for j=1:nsplits
        figure(nfactor*i+j)
        
        idx1=1+l*(j-1):l*j;
        idx2=1+l*(i-1):l*i;
        
        %saturate indices if needed
        idx1=unique(min(idx1,n));
        idx2=unique(min(idx2,n));
        
        X1=X(:,idx1);
        X2=X(:,idx2);
        [~,ax] = plotmatrix(X1,X2);
        
        %add labels
        for ii=1:size(ax,2)
            xlabel(ax(end,ii),num2str(idx1(ii)))
        end
        for ii=1:size(ax,1)
            ylabel(ax(ii,1),num2str(idx2(ii)))
        end
        
        for ii=1:size(ax,1)
            for jj=1:size(ax,2)
                h=ax(ii,jj);
                h.XTick=[];
                h.YTick=[];
            end
        end
        
        if doSave
            idxstring=[num2str(idx2(1)),'to',num2str(idx2(end)),'_',...
                num2str(idx1(1)),'to',num2str(idx1(end))];
            exportgraphics(gcf,[cartella,'/scatterMatrix_',idxstring,'.tiff'],'Resolution',1000);
        end
        
    end
end


end

