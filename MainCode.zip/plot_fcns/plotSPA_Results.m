function plotSPA_Results(y,y_hat,DatasetLabel,varargin)
% plotSPA_Results(y,y_hat,DatasetLabel,varargin)
% Plot modelling results (residual analysis, data vs model predictions)
%Inputs:
% y: array, target data
% y_hat: array, model prediction 
% DatasetLabel: string, information about the dataset
% [y_CI]: matrix, lower and upper values of confidence intervals for y

%%
if length(varargin)==0
    plotCI=0;
else
    plotCI=1;
    y_CI=varargin{1};
end

%%

if size(y)~=size(y_hat)
    y=y';
end

e=y-y_hat;

figure();
set(gcf,'Name',['Residual_Plot',DatasetLabel]);

subplot(2,2,1)
histogram(e,'Normalization','pdf')
hold on
grid on
xline(0,'--r')
xlabel('Residual')
ylabel('Frequency')
title(['Residual Histogram -',DatasetLabel])

subplot(2,2,2)
plot(e,'x')
hold on
grid on
yline(0,'--r')
xlabel('Sample Number')
ylabel('Residual')
title(['Residual -',DatasetLabel])

subplot(2,2,3)
qqplot(e)
grid on
xlabel('Theoretical Quartiles')
ylabel('Sample Quartiles')
title(['Normal Q-Q Plot -',DatasetLabel])


subplot(2,2,4)
plot(y_hat,e,'x')
hold on
grid on
yline(0,'--r')
xlabel('Fitted Response')
ylabel('Residual')
title(['Residual vs Fitted Response -',DatasetLabel])

figure();
set(gcf,'Name',['Fit_Plot_',DatasetLabel]);

plot(y,y_hat,'x')
hold on
grid on
plot(y,y,'-k')
xlabel('Data')
ylabel('Fitted Response')
title(['Data vs Fitted Response -',DatasetLabel])


figure();
set(gcf,'Name',['Fit_Plot_2_',DatasetLabel]);

plot(y,'-o')
hold on
plot(y_hat,'-x')
if plotCI
    plot(y_CI,':k')
end
grid on
xlabel('Sample Number')
ylabel('Data and Fitted Response')
if plotCI==0
legend('Data','Fitted Response')
else
    legend('Data','Fitted Response','95% Confidence Interval')
end
title(['Data and Fitted Response -',DatasetLabel])
end

