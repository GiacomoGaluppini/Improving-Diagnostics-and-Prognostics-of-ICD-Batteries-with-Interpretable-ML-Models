clear all
close all
clc

Qname='TotalPre_PulseQ';
% Qname='TotalPost_PulseQ';
%%
load('summaryTargetData.mat')
load('SernTable.mat')
load('TargetFeatures_DPClustering.mat')
%%
SernTable=removevars(SernTable,{'ID','TCODE','POSITION'});
if sum(ismember(summaryTargetData.Properties.VariableNames,'SERN'))>0
    SERN=intersect(summaryTargetData.SERN,SernTable.SERN);

    summaryTargetData=summaryTargetData(ismember(summaryTargetData.SERN,SERN),:);
    SernTable=SernTable(ismember(SernTable.SERN,SERN),:);

    summaryTargetData = join(SernTable,summaryTargetData);
end

%%

PulseDuration=cell(height(TargetFeatures),4);
Q_PulseDuration=cell(height(TargetFeatures),4);

PulseAvgV=cell(height(TargetFeatures),4);
Q_PulseAvgV=cell(height(TargetFeatures),4);

sn=intersect(summaryTargetData.SerialNumber,TargetFeatures.SerialNumber);

for i=1:height(TargetFeatures)
    idx=find(strcmp(TargetFeatures.SerialNumber(i),summaryTargetData.SerialNumber));
    if ~isempty(idx)

        tmp=summaryTargetData(idx,:);
        tmp=tmp.PulseTargetData{:};

        for j=1:4
            idxgood=find(tmp.PULSENO==j);

            if isempty(idxgood)
                PulseAvgV{i,j}=nan;
                Q_PulseAvgV{i,j}=nan;

                PulseDuration{i,j}=nan;
                Q_PulseDuration{i,j}=nan;
            else
                PulseAvgV{i,j}=tmp{idxgood,"AVERAGEV"};
                Q_PulseAvgV{i,j}=tmp{idxgood,Qname};

                PulseDuration{i,j}=tmp{idxgood,"PULSETIME"};
                Q_PulseDuration{i,j}=tmp{idxgood,Qname};
            end
        end

    else
        for j=1:4
            PulseAvgV{i,j}=nan;
            Q_PulseAvgV{i,j}=nan;

            PulseDuration{i,j}=nan;
            Q_PulseDuration{i,j}=nan;
        end
    end

end

%% add pulse duration
for i=1:4
TargetFeatures = addvars(TargetFeatures,PulseDuration(:,i),'NewVariableNames',['PulseDuration_',num2str(i)]);
end

for i=1:4
TargetFeatures = addvars(TargetFeatures,Q_PulseDuration(:,i),'NewVariableNames',['Q_PulseDuration_',num2str(i)]);
end

%% add average voltage

for i=1:4
TargetFeatures = addvars(TargetFeatures,PulseAvgV(:,i),'NewVariableNames',['PulseAvgV_',num2str(i)]);
end

for i=1:4
TargetFeatures = addvars(TargetFeatures,Q_PulseAvgV(:,i),'NewVariableNames',['Q_PulseAvgV_',num2str(i)]);
end

%% save

save('TargetFeatures_DPClustering_plusSummary.mat','TargetFeatures')